# FBs10 Browser

هذا المشروع يستخدم نفس بنية FBs10 الذي كان يبنى بنجاح:
- Android Gradle Plugin 8.2.2
- Gradle 8.2.1
- Java 17
- compileSdk 34
- minSdk 24
- armeabi-v7a فقط

ارفع محتويات ZIP إلى جذر مستودع GitHub، وليس ZIP داخل مجلد آخر.
يجب أن تظهر في الجذر:
settings.gradle
build.gradle
gradle.properties
app/
.github/workflows/build-apk.yml

ثم Actions → Build FBs10 Browser APK → Run workflow.

المشروع يحتوي على أساس المتصفح والميزات الأساسية والمتقدمة الممكن تنفيذها داخل WebView. إضافات Chrome الكاملة ليست مدعومة بواسطة WebView نفسه، لذلك لا يتم الادعاء بأنها تعمل كإضافات Chrome حقيقية.
