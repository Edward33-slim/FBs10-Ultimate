package com.fbs10.browser;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.webkit.*;
import android.widget.*;
import java.io.*;
import java.util.*;
import android.app.DownloadManager;
import android.os.Environment;

public class MainActivity extends Activity {
    static final String HOME="https://www.google.com/";
    LinearLayout root, toolbar, webHost;
    EditText address;
    TextView tabCount;
    ArrayList<WebView> tabs=new ArrayList<>();
    ArrayList<String> urls=new ArrayList<>();
    ArrayList<String> titles=new ArrayList<>();
    ArrayList<String> history=new ArrayList<>();
    ArrayList<String> bookmarks=new ArrayList<>();
    ArrayList<String> homeLinks=new ArrayList<>();
    int current=0;
    boolean incognito=false, dark=false, desktop=false, hideMedia=false, adBlock=true;
    SharedPreferences pref;

    int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    TextView button(String s){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(18);t.setGravity(Gravity.CENTER);t.setPadding(dp(4),0,dp(4),0);return t;}
    GradientDrawable round(int c){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(22));return g;}

    @Override public void onCreate(Bundle b){
        super.onCreate(b); getWindow().setStatusBarColor(Color.BLACK);getWindow().setNavigationBarColor(Color.BLACK);
        pref=getSharedPreferences("fbs10_browser",0); load(); build(); addTab(HOME,false);
    }

    void build(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.BLACK);
        toolbar=new LinearLayout(this);toolbar.setGravity(Gravity.CENTER_VERTICAL);toolbar.setPadding(dp(4),dp(4),dp(4),dp(4));
        TextView menu=button("⋮"), star=button("☆"), home=button("⌂"), plus=button("+"), reload=button("↻");
        tabCount=button("1");
        address=new EditText(this);address.setSingleLine(true);address.setTextColor(Color.WHITE);address.setHintTextColor(Color.GRAY);
        address.setHint("بحث أو إدخال عنوان");address.setTextSize(15);address.setPadding(dp(12),0,dp(12),0);address.setBackground(round(Color.rgb(35,35,35)));
        toolbar.addView(menu,new LinearLayout.LayoutParams(dp(36),dp(46)));
        toolbar.addView(star,new LinearLayout.LayoutParams(dp(36),dp(46)));
        toolbar.addView(address,new LinearLayout.LayoutParams(0,dp(46),1));
        toolbar.addView(tabCount,new LinearLayout.LayoutParams(dp(42),dp(46)));
        toolbar.addView(home,new LinearLayout.LayoutParams(dp(36),dp(46)));
        toolbar.addView(plus,new LinearLayout.LayoutParams(dp(36),dp(46)));
        toolbar.addView(reload,new LinearLayout.LayoutParams(dp(42),dp(46)));
        webHost=new LinearLayout(this);webHost.setOrientation(LinearLayout.VERTICAL);webHost.setBackgroundColor(Color.BLACK);
        root.addView(toolbar);root.addView(webHost,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
        address.setOnEditorActionListener((v,a,e)->{navigate(address.getText().toString());return true;});
        menu.setOnClickListener(v->showMenu());star.setOnClickListener(v->bookmark());home.setOnClickListener(v->navigate(HOME));
        plus.setOnClickListener(v->addTab(HOME,false));reload.setOnClickListener(v->web().reload());tabCount.setOnClickListener(v->showTabs());
    }

    WebView web(){return tabs.get(current);}
    WebView makeWeb(){
        WebView w=new WebView(this); WebSettings s=w.getSettings();
        s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setDatabaseEnabled(true);
        s.setSupportZoom(true);s.setBuiltInZoomControls(true);s.setDisplayZoomControls(false);
        s.setLoadsImagesAutomatically(!hideMedia);s.setAllowFileAccess(true);s.setAllowContentAccess(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);s.setMediaPlaybackRequiresUserGesture(false);
        setUA(s);
        w.setBackgroundColor(Color.WHITE);
        w.setWebViewClient(new WebViewClient(){
            @Override public void onPageStarted(WebView v,String u,android.graphics.Bitmap b){address.setText(u);}
            @Override public void onPageFinished(WebView v,String u){
                address.setText(u);if(!incognito){addHistory(u);save();}if(dark)dark(v);
                urls.set(current,u);titles.set(current,v.getTitle()==null?"":v.getTitle());saveTabs();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){
                String u=r.getUrl().toString(); if(u.startsWith("http://")||u.startsWith("https://"))return false;
                try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));}catch(Exception ignored){} return true;
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){
                if(adBlock && blocked(r.getUrl().toString()))return new WebResourceResponse("text/plain","utf-8",new ByteArrayInputStream(new byte[0]));
                return super.shouldInterceptRequest(v,r);
            }
            @Override public void onReceivedSslError(WebView v,SslErrorHandler h,SslError e){
                new AlertDialog.Builder(MainActivity.this).setTitle("⚠ تحذير أمني")
                .setMessage("تعذر التحقق من شهادة أمان الموقع. قد يكون الاتصال غير آمن.\n\nيمكنك العودة أو المتابعة على مسؤوليتك.")
                .setNegativeButton("العودة",(d,x)->h.cancel()).setPositiveButton("المتابعة",(d,x)->h.proceed()).show();
            }
        });
        w.setDownloadListener((u,ua,cd,mime,len)->downloadDialog(u,ua,cd,mime));
        return w;
    }
    void setUA(WebSettings s){if(desktop)s.setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120 Safari/537.36");else s.setUserAgentString(null);}
    boolean blocked(String u){String x=u.toLowerCase(Locale.US);String[] a={"doubleclick.net","googlesyndication.com","googleadservices.com","adservice.google.com","advertising.com","scorecardresearch.com","adsystem.com"};for(String h:a)if(x.contains(h))return true;return x.contains("/ads/")||x.contains("adsbygoogle");}

    void addTab(String u,boolean priv){
        incognito=priv;WebView w=makeWeb();tabs.add(w);urls.add(u);titles.add("");current=tabs.size()-1;showCurrent();w.loadUrl(u);updateTabs();saveTabs();
    }
    void showCurrent(){webHost.removeAllViews();webHost.addView(web(),new LinearLayout.LayoutParams(-1,-1));address.setText(web().getUrl());}
    void switchTab(int n){if(n<0||n>=tabs.size())return;current=n;showCurrent();updateTabs();}
    void updateTabs(){tabCount.setText(String.valueOf(tabs.size()));}

    void navigate(String q){
        String u=q.trim();if(u.isEmpty())return;
        if(!u.matches("(?i)^https?://.*")){if(u.contains(".")&&!u.contains(" "))u="https://"+u;else u=HOME+"search?q="+Uri.encode(u);}
        web().loadUrl(u);hideKeyboard();
    }
    void hideKeyboard(){((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(address.getWindowToken(),0);address.clearFocus();}
    void bookmark(){String u=web().getUrl();if(u==null)return;if(bookmarks.contains(u)){bookmarks.remove(u);Toast.makeText(this,"تم حذف الإشارة المرجعية",0).show();}else{bookmarks.add(u);Toast.makeText(this,"تمت إضافة الإشارة المرجعية",0).show();}save();}

    void showTabs(){
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(8),dp(4),dp(8),dp(4));
        for(int i=0;i<tabs.size();i++){final int n=i;TextView t=button((i+1)+"  "+(titles.get(i).isEmpty()?urls.get(i):titles.get(i)));t.setGravity(Gravity.CENTER_VERTICAL);t.setTextSize(14);
            t.setOnClickListener(v->{switchTab(n);});l.addView(t,new LinearLayout.LayoutParams(-1,dp(50)));}
        new AlertDialog.Builder(this).setTitle("الصفحات المفتوحة").setView(l).setPositiveButton("تبويب جديد",(d,w)->addTab(HOME,false)).setNegativeButton("إغلاق",null).show();
    }

    void showMenu(){
        String[] a={"الإضافات Chrome","الإعدادات","السجل","التنزيلات","الإشارات المرجعية","تبويب متخفي","الوضع الليلي","إخفاء الصور والفيديو","عرض سطح المكتب","تبويب جديد","منع الإعلانات"};
        new AlertDialog.Builder(this).setItems(a,(d,n)->{
            switch(n){
                case 0: chromeExtensions();break;case 1:settings();break;case 2:listDialog("السجل",history);break;
                case 3:try{startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS));}catch(Exception e){}break;
                case 4:bookmarksDialog();break;case 5:addTab(HOME,true);break;
                case 6:dark=!dark;if(dark)dark(web());else web().reload();break;
                case 7:hideMedia=!hideMedia;web().getSettings().setLoadsImagesAutomatically(!hideMedia);web().reload();break;
                case 8:desktop=!desktop;setUA(web().getSettings());web().reload();break;
                case 9:addTab(HOME,false);break;case 10:adBlock=!adBlock;Toast.makeText(this,adBlock?"منع الإعلانات: قوي":"منع الإعلانات: متوقف",0).show();break;
            }
        }).show();
    }

    void chromeExtensions(){
        new AlertDialog.Builder(this).setTitle("إضافات Chrome")
        .setMessage("هذا المتصفح يجهز واجهة الإضافات. تشغيل إضافات Chrome الكاملة يحتاج محرك إضافات متوافق؛ WebView وحده لا يشغّل إضافات Chrome الكاملة.\n\nيمكن لاحقًا إضافة مدير إضافات مستقل دون ادعاء دعم غير موجود.")
        .setPositiveButton("حسنًا",null).show();
    }

    void settings(){
        String[] a={"تكبير/تصغير حجم الخط","العربية / English","ملفات تعريف الارتباط","النوافذ المنبثقة","منع الإعلانات: خفيف / قوي","قواعد منع الإعلانات","التنزيلات","مجلد التنزيل","علامات المرجعية واستيراد/تصدير HTML","مسح السجل والكاش"};
        new AlertDialog.Builder(this).setTitle("الإعدادات").setItems(a,(d,n)->{
            if(n==0)fontSize();else if(n==1)language();else if(n==2)cookies();else if(n==3)popups();else if(n==4)adMode();else if(n==5)rules();else if(n==6)downloadSettings();else if(n==7)Toast.makeText(this,"يستخدم مجلد Downloads الافتراضي حاليًا",0).show();else if(n==8)bookmarkTools();else if(n==9)clearData();
        }).show();
    }
    void fontSize(){String[] a={"80%","90%","100%","110%","120%","130%","150%","170%"};new AlertDialog.Builder(this).setTitle("حجم الخط").setItems(a,(d,n)->{web().getSettings().setTextZoom(new int[]{80,90,100,110,120,130,150,170}[n]);}).show();}
    void language(){new AlertDialog.Builder(this).setTitle("لغة المتصفح").setItems(new String[]{"العربية","English"},null).show();}
    void cookies(){new AlertDialog.Builder(this).setTitle("ملفات تعريف الارتباط").setItems(new String[]{"السماح","حظر ملفات الطرف الثالث","حظر الكل"},(d,n)->{CookieManager c=CookieManager.getInstance();c.setAcceptCookie(n!=2);c.setAcceptThirdPartyCookies(web(),n==0);}).show();}
    void popups(){new AlertDialog.Builder(this).setTitle("النوافذ المنبثقة").setItems(new String[]{"السماح","منع"},(d,n)->web().getSettings().setJavaScriptCanOpenWindowsAutomatically(n==0)).show();}
    void adMode(){new AlertDialog.Builder(this).setTitle("منع الإعلانات").setItems(new String[]{"متوقف","خفيف","قوي"},(d,n)->{adBlock=n>0;Toast.makeText(this,"تم اختيار "+(n==2?"قوي":n==1?"خفيف":"متوقف"),0).show();}).show();}
    void rules(){new AlertDialog.Builder(this).setTitle("قواعد منع الإعلانات").setMessage("القواعد المدمجة تشمل نطاقات إعلانية شائعة. إضافة/حذف/تحديث قوائم كبيرة تحتاج مدير قواعد منفصل في مرحلة لاحقة.").setPositiveButton("حسنًا",null).show();}
    void downloadSettings(){new AlertDialog.Builder(this).setTitle("التنزيلات").setItems(new String[]{"التنزيل من FBs10","السؤال قبل التنزيل","فتح مدير تنزيل النظام"},(d,n)->{if(n==2)try{startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS));}catch(Exception e){}}).show();}
    void clearData(){new AlertDialog.Builder(this).setTitle("مسح البيانات").setItems(new String[]{"مسح السجل","مسح الكاش","مسح Cookies وبيانات المواقع"},(d,n)->{if(n==0){history.clear();save();}else if(n==1){web().clearCache(true);}else{CookieManager.getInstance().removeAllCookies(null);CookieManager.getInstance().flush();web().clearHistory();web().clearCache(true);}Toast.makeText(this,"تم",0).show();}).show();}

    void listDialog(String title,ArrayList<String> list){if(list.isEmpty()){Toast.makeText(this,"القائمة فارغة",0).show();return;}new AlertDialog.Builder(this).setTitle(title).setItems(list.toArray(new String[0]),(d,n)->navigate(list.get(n))).setNegativeButton("إغلاق",null).show();}
    void bookmarksDialog(){listDialog("الإشارات المرجعية",bookmarks);}
    void bookmarkTools(){new AlertDialog.Builder(this).setTitle("علامات المرجعية").setItems(new String[]{"تصدير HTML","استيراد HTML","إضافة مجلد"},(d,n)->{if(n==0)exportHtml();else if(n==1)importHtml();else Toast.makeText(this,"المجلدات ستضاف إلى مدير الإشارات المرجعية المتقدم",0).show();}).show();}

    void exportHtml(){
        try{File f=new File(getExternalFilesDir(null),"FBs10_bookmarks.html");FileWriter w=new FileWriter(f);w.write("<!DOCTYPE NETSCAPE-Bookmark-file-1><META charset=\"UTF-8\"><TITLE>FBs10 Bookmarks</TITLE><H1>Bookmarks</H1><DL><p>");
            for(String u:bookmarks)w.write("<DT><A HREF=\""+escape(u)+"\">"+escape(u)+"</A>\n");w.write("</DL><p>");w.close();
            Toast.makeText(this,"تم التصدير: "+f.getAbsolutePath(),0).show();
        }catch(Exception e){Toast.makeText(this,"فشل التصدير",0).show();}
    }
    String escape(String x){return x.replace("&","&amp;").replace("\"","&quot;").replace("<","&lt;").replace(">","&gt;");}
    void importHtml(){Toast.makeText(this,"اختر ملف HTML من مدير الملفات في النسخة المتقدمة",0).show();}

    void downloadDialog(String u,String ua,String cd,String mime){
        new AlertDialog.Builder(this).setTitle("التنزيل").setItems(new String[]{"تنزيل من FBs10","تنزيل من متصفح/تطبيق آخر"},(d,n)->{
            if(n==0)enqueue(u,ua,cd,mime);else{try{Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(u));startActivity(i);}catch(Exception e){}}
        }).show();
    }
    void enqueue(String u,String ua,String cd,String mime){
        try{DownloadManager.Request r=new DownloadManager.Request(Uri.parse(u));r.setMimeType(mime);r.addRequestHeader("User-Agent",ua);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,URLUtil.guessFileName(u,cd,mime));
            ((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(r);Toast.makeText(this,"بدأ التنزيل",0).show();
        }catch(Exception e){Toast.makeText(this,"تعذر بدء التنزيل",0).show();}
    }

    void dark(WebView v){v.loadUrl("javascript:(function(){var s=document.getElementById('__fbs10dark');if(!s){s=document.createElement('style');s.id='__fbs10dark';document.head.appendChild(s);}s.innerHTML='html{filter:invert(.9) hue-rotate(180deg)!important}img,video,iframe{filter:invert(1) hue-rotate(180deg)!important}';})()");}

    void addHistory(String u){if(u==null||u.startsWith("about:"))return;history.remove(u);history.add(0,u);while(history.size()>300)history.remove(history.size()-1);}
    void save(){pref.edit().putString("history",join(history)).putString("bookmarks",join(bookmarks)).putString("homeLinks",join(homeLinks)).apply();}
    void load(){history=split(pref.getString("history",""));bookmarks=split(pref.getString("bookmarks",""));homeLinks=split(pref.getString("homeLinks",""));}
    void saveTabs(){StringBuilder s=new StringBuilder();for(String u:urls){if(s.length()>0)s.append("\n");s.append(u==null?"":u);}pref.edit().putString("tabs",s.toString()).apply();}
    String join(ArrayList<String>a){StringBuilder s=new StringBuilder();for(String x:a){if(s.length()>0)s.append("\n");s.append(x.replace("\n",""));}return s.toString();}
    ArrayList<String> split(String s){ArrayList<String>a=new ArrayList<>();if(s==null||s.isEmpty())return a;for(String x:s.split("\\n"))if(!x.isEmpty())a.add(x);return a;}

    @Override public void onBackPressed(){if(web().canGoBack())web().goBack();else if(tabs.size()>1){web().destroy();tabs.remove(current);urls.remove(current);titles.remove(current);current=Math.max(0,current-1);showCurrent();updateTabs();}else super.onBackPressed();}
    @Override protected void onDestroy(){saveTabs();for(WebView w:tabs)w.destroy();super.onDestroy();}
}
