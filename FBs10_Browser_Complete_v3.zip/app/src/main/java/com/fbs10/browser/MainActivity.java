package com.fbs10.browser;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.webkit.*;
import android.widget.*;
import java.util.*;
import java.io.*;
import android.app.DownloadManager;
import android.os.Environment;

public class MainActivity extends Activity {
    static final String HOME = "https://www.google.com/";
    LinearLayout root, toolbar, content, bottom;
    EditText address;
    TextView tabsButton, title;
    ArrayList<WebView> tabs = new ArrayList<>();
    ArrayList<String> history = new ArrayList<>();
    ArrayList<String> bookmarks = new ArrayList<>();
    int current = 0;
    boolean incognito = false, desktop = false, dark = false, blockImages = false, adBlock = true;

    int dp(int v){ return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        loadData();
        buildUi();
        addTab(HOME, false);
    }

    TextView btn(String s) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(18);
        t.setGravity(Gravity.CENTER); t.setPadding(dp(5),0,dp(5),0);
        return t;
    }

    GradientDrawable bg(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(radius));
        return g;
    }

    void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);

        toolbar = new LinearLayout(this);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(4),dp(4),dp(4),dp(4));
        toolbar.setBackgroundColor(Color.BLACK);

        TextView back = btn("‹");
        TextView forward = btn("›");
        TextView reload = btn("↻");
        TextView menu = btn("⋮");
        tabsButton = btn("1");

        address = new EditText(this);
        address.setSingleLine(true);
        address.setTextColor(Color.WHITE);
        address.setHintTextColor(Color.LTGRAY);
        address.setHint("بحث أو إدخال عنوان");
        address.setTextSize(15);
        address.setPadding(dp(10),0,dp(10),0);
        address.setBackground(bg(Color.rgb(35,35,35), 22));

        toolbar.addView(back, new LinearLayout.LayoutParams(dp(38),dp(46)));
        toolbar.addView(forward, new LinearLayout.LayoutParams(dp(38),dp(46)));
        toolbar.addView(address, new LinearLayout.LayoutParams(0,dp(46),1));
        toolbar.addView(reload, new LinearLayout.LayoutParams(dp(42),dp(46)));
        toolbar.addView(tabsButton, new LinearLayout.LayoutParams(dp(42),dp(46)));
        toolbar.addView(menu, new LinearLayout.LayoutParams(dp(38),dp(46)));

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);

        bottom = new LinearLayout(this);
        bottom.setGravity(Gravity.CENTER);
        bottom.setBackgroundColor(Color.BLACK);
        TextView home = btn("⌂"), bback = btn("←"), bforward = btn("→"), star = btn("☆");
        bottom.addView(home,new LinearLayout.LayoutParams(0,dp(48),1));
        bottom.addView(bback,new LinearLayout.LayoutParams(0,dp(48),1));
        bottom.addView(bforward,new LinearLayout.LayoutParams(0,dp(48),1));
        bottom.addView(star,new LinearLayout.LayoutParams(0,dp(48),1));

        root.addView(toolbar);
        root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
        root.addView(bottom);
        setContentView(root);

        address.setOnEditorActionListener((v,a,e)->{ navigate(address.getText().toString()); return true; });
        back.setOnClickListener(v->{ if(currentWeb().canGoBack()) currentWeb().goBack(); });
        forward.setOnClickListener(v->{ if(currentWeb().canGoForward()) currentWeb().goForward(); });
        reload.setOnClickListener(v->currentWeb().reload());
        home.setOnClickListener(v->navigate(HOME));
        bback.setOnClickListener(v->{ if(currentWeb().canGoBack()) currentWeb().goBack(); });
        bforward.setOnClickListener(v->{ if(currentWeb().canGoForward()) currentWeb().goForward(); });
        star.setOnClickListener(v->bookmarkCurrent());
        tabsButton.setOnClickListener(v->showTabs());
        menu.setOnClickListener(v->showMenu());
    }

    WebView currentWeb(){ return tabs.get(current); }

    WebView newWebView() {
        WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);

        // Pinch-to-zoom on any web page.
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);

        s.setLoadsImagesAutomatically(!blockImages);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        w.setBackgroundColor(Color.WHITE);

        applyUserAgent(s);

        w.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView v, String url, android.graphics.Bitmap f) {
                address.setText(url);
                address.setSelection(address.length());
            }
            @Override public void onPageFinished(WebView v, String url) {
                address.setText(url);
                address.setSelection(address.length());
                if (!incognito) addHistory(url);
                if (dark) injectDarkMode(v);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                if (u.startsWith("http://") || u.startsWith("https://")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u))); } catch(Exception ignored){}
                return true;
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                if (adBlock && isBlocked(r.getUrl().toString())) {
                    return new WebResourceResponse("text/plain","utf-8",
                            new ByteArrayInputStream(new byte[0]));
                }
                return super.shouldInterceptRequest(v,r);
            }
            @Override public void onReceivedSslError(WebView v, SslErrorHandler h, SslError e) {
                new AlertDialog.Builder(MainActivity.this)
                    .setTitle("تحذير أمني")
                    .setMessage("تعذر التحقق من شهادة أمان الموقع. المتابعة قد تكون غير آمنة.")
                    .setNegativeButton("العودة",(d,x)->h.cancel())
                    .setPositiveButton("المتابعة",(d,x)->h.proceed()).show();
            }
        });

        w.setDownloadListener((url,userAgent,contentDisposition,mimeType,contentLength)->{
            try {
                DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                req.setMimeType(mimeType);
                req.addRequestHeader("User-Agent",userAgent);
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                        URLUtil.guessFileName(url,contentDisposition,mimeType));
                ((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(req);
                Toast.makeText(this,"بدأ التنزيل",Toast.LENGTH_SHORT).show();
            } catch(Exception e) { Toast.makeText(this,"تعذر بدء التنزيل",Toast.LENGTH_SHORT).show(); }
        });
        return w;
    }

    void applyUserAgent(WebSettings s) {
        if (desktop) {
            s.setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120 Safari/537.36");
        } else {
            s.setUserAgentString(null);
        }
    }

    boolean isBlocked(String u) {
        String x=u.toLowerCase(Locale.US);
        String[] hosts={"doubleclick.net","googlesyndication.com","googleadservices.com",
                "adservice.google.com","adsystem.com","advertising.com","scorecardresearch.com"};
        for(String h:hosts) if(x.contains(h)) return true;
        return x.contains("/ads/") || x.contains("adsbygoogle");
    }

    void injectDarkMode(WebView v) {
        String js="javascript:(function(){var s=document.getElementById('__fbs10_dark');"
            +"if(!s){s=document.createElement('style');s.id='__fbs10_dark';document.head.appendChild(s);}"
            +"s.innerHTML='html{filter:invert(0.9) hue-rotate(180deg)!important;} img,video,iframe{filter:invert(1) hue-rotate(180deg)!important;}';})()";
        v.loadUrl(js);
    }

    void addTab(String url, boolean privateTab) {
        incognito = privateTab;
        WebView w = newWebView();
        tabs.add(w);
        current = tabs.size()-1;
        content.removeAllViews();
        content.addView(w,new LinearLayout.LayoutParams(-1,-1));
        w.loadUrl(url);
        updateTabs();
    }

    void switchTab(int n) {
        if(n<0 || n>=tabs.size()) return;
        current=n;
        content.removeAllViews();
        content.addView(currentWeb(),new LinearLayout.LayoutParams(-1,-1));
        address.setText(currentWeb().getUrl());
        updateTabs();
    }

    void navigate(String q) {
        String u=q.trim();
        if(u.length()==0) return;
        if(!u.matches("(?i)^https?://.*")) {
            if(u.contains(".") && !u.contains(" ")) u="https://"+u;
            else u=HOME+"search?q="+Uri.encode(u);
        }
        currentWeb().loadUrl(u);
        hideKeyboard();
    }

    void hideKeyboard() {
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(address.getWindowToken(),0);
        address.clearFocus();
    }

    void updateTabs(){ tabsButton.setText(String.valueOf(tabs.size())); }

    void addHistory(String url) {
        if(url==null || url.startsWith("about:") || url.startsWith("data:")) return;
        history.remove(url); history.add(0,url);
        while(history.size()>200) history.remove(history.size()-1);
        saveData();
    }

    void bookmarkCurrent() {
        String u=currentWeb().getUrl();
        if(u==null) return;
        if(bookmarks.contains(u)) {
            bookmarks.remove(u);
            Toast.makeText(this,"أزيلت من الإشارات المرجعية",Toast.LENGTH_SHORT).show();
        } else {
            bookmarks.add(u);
            Toast.makeText(this,"تمت إضافة الإشارة المرجعية",Toast.LENGTH_SHORT).show();
        }
        saveData();
    }

    void showTabs() {
        LinearLayout l=new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(10),dp(5),dp(10),dp(5));
        for(int i=0;i<tabs.size();i++){
            final int n=i;
            TextView t=btn((i+1)+". "+safeTitle(tabs.get(i).getTitle(),tabs.get(i).getUrl()));
            t.setGravity(Gravity.CENTER_VERTICAL);
            t.setTextSize(14);
            t.setOnClickListener(v->{switchTab(n);});
            l.addView(t,new LinearLayout.LayoutParams(-1,dp(52)));
        }
        new AlertDialog.Builder(this).setTitle("علامات التبويب")
            .setView(l)
            .setPositiveButton("تبويب جديد", (d,w)->addTab(HOME,false))
            .setNeutralButton("متخفي", (d,w)->addTab(HOME,true))
            .setNegativeButton("إغلاق",null).show();
    }

    String safeTitle(String a,String b) {
        if(a!=null && a.length()>0) return a;
        return b==null ? "صفحة جديدة" : b;
    }

    void showMenu() {
        String[] items={
            "تبويب جديد","تبويب متخفي","السجل","الإشارات المرجعية","التنزيلات",
            "عرض سطح المكتب","الوضع الليلي","إخفاء الصور","منع الإعلانات",
            "إظهار الصفحة الرئيسية","مسح بيانات التصفح"
        };
        new AlertDialog.Builder(this).setItems(items,(d,which)->{
            switch(which){
                case 0: addTab(HOME,false); break;
                case 1: addTab(HOME,true); break;
                case 2: showList("السجل",history); break;
                case 3: showList("الإشارات المرجعية",bookmarks); break;
                case 4: startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)); break;
                case 5: desktop=!desktop; currentWeb().getSettings().setUserAgentString(null);
                        applyUserAgent(currentWeb().getSettings()); currentWeb().reload(); break;
                case 6: dark=!dark; if(dark) injectDarkMode(currentWeb()); else currentWeb().reload(); break;
                case 7: blockImages=!blockImages; currentWeb().getSettings().setLoadsImagesAutomatically(!blockImages); currentWeb().reload(); break;
                case 8: adBlock=!adBlock; Toast.makeText(this,adBlock?"منع الإعلانات: تشغيل":"منع الإعلانات: إيقاف",Toast.LENGTH_SHORT).show(); break;
                case 9: navigate(HOME); break;
                case 10: history.clear(); saveData(); Toast.makeText(this,"تم مسح السجل",Toast.LENGTH_SHORT).show(); break;
            }
        }).show();
    }

    void showList(String title, ArrayList<String> list) {
        if(list.isEmpty()){ Toast.makeText(this,"القائمة فارغة",Toast.LENGTH_SHORT).show(); return; }
        String[] a=list.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle(title).setItems(a,(d,w)->navigate(a[w])).setNegativeButton("إغلاق",null).show();
    }

    void saveData() {
        getSharedPreferences("fbs10",0).edit()
            .putString("history",join(history))
            .putString("bookmarks",join(bookmarks)).apply();
    }

    void loadData() {
        String h=getSharedPreferences("fbs10",0).getString("history","");
        String b=getSharedPreferences("fbs10",0).getString("bookmarks","");
        history=split(h); bookmarks=split(b);
    }

    String join(ArrayList<String> a) {
        StringBuilder s=new StringBuilder();
        for(String x:a){ if(s.length()>0)s.append("\n"); s.append(x.replace("\n","")); }
        return s.toString();
    }

    ArrayList<String> split(String s) {
        ArrayList<String> a=new ArrayList<>();
        if(s==null || s.isEmpty()) return a;
        for(String x:s.split("\\n")) if(x.length()>0) a.add(x);
        return a;
    }

    @Override public void onBackPressed() {
        if(currentWeb().canGoBack()) currentWeb().goBack();
        else if(tabs.size()>1) {
            WebView old=tabs.remove(current);
            old.destroy();
            current=Math.max(0,current-1);
            switchTab(current);
        } else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        saveData();
        for(WebView w:tabs) w.destroy();
        super.onDestroy();
    }
}
