ارفع المجلد إلى GitHub. بعد الرفع:
Actions → Build BRs10 APK → Run workflow.
سيبني GitHub نسخة Debug APK ويرفعها كـ Artifact باسم BRs10-debug-apk.
