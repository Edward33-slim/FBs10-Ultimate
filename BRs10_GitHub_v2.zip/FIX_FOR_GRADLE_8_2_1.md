# إصلاح فشل البناء

سبب الفشل في النسخة السابقة هو استخدام Android Gradle Plugin 8.5.2 بينما بيئة GitHub الظاهرة لديك تستخدم Gradle 8.2.1.

هذه النسخة تستخدم:
- Android Gradle Plugin 8.2.2
- Gradle 8.2.1
- Java 17
- compileSdk 35
- minSdk 24 (Android 7+)

بعد رفع الملفات إلى GitHub:
1. ادخل إلى Actions.
2. اختر Build BRs10 APK.
3. اضغط Run workflow.
4. إذا نجح البناء ستجد BRs10-release-APK في Artifacts.

إذا كان لديك Workflow قديم باسم build-apk.yml، احذفه أو استبدله بالملف الموجود في:
.github/workflows/build.yml
