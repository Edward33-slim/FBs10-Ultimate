# FBs10

Modified Android project for Code2Native.

Key changes: persistent preferences/session-friendly WebView settings, single dark mode, moon icon, Facebook messages URL, message/notification badges, lighter media handling, suggestion hiding, and improved loading behavior for weak networks.

Note: Facebook/Meta may change its web UI, so DOM-based features can require future maintenance.
