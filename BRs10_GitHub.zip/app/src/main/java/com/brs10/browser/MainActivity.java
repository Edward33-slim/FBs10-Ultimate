package com.brs10.browser;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.webkit.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, bar, content;
    EditText address;
    ArrayList<WebView> tabs = new ArrayList<>();
    int current = 0;
    TextView tabCount;

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.BLACK);
        build();
        addTab("https://www.google.com");
    }

    TextView button(String text){
        TextView v=new TextView(this);
        v.setText(text); v.setTextColor(Color.WHITE); v.setTextSize(18);
        v.setGravity(Gravity.CENTER); v.setPadding(dp(7),0,dp(7),0);
        return v;
    }

    void build(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.BLACK);
        bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(dp(4),dp(4),dp(4),dp(4));
        bar.setBackgroundColor(Color.BLACK);

        TextView menu=button("⋮");
        TextView home=button("⌂");
        TextView star=button("☆");
        tabCount=button("1");

        address=new EditText(this);
        address.setSingleLine(true); address.setTextColor(Color.WHITE); address.setHintTextColor(Color.GRAY);
        address.setHint("بحث أو إدخال عنوان");
        address.setTextSize(15); address.setBackgroundColor(Color.rgb(35,35,35));
        address.setPadding(dp(10),0,dp(10),0);
        bar.addView(menu,new LinearLayout.LayoutParams(dp(35),dp(46)));
        bar.addView(star,new LinearLayout.LayoutParams(dp(35),dp(46)));
        bar.addView(address,new LinearLayout.LayoutParams(0,dp(46),1));
        bar.addView(tabCount,new LinearLayout.LayoutParams(dp(42),dp(46)));
        bar.addView(home,new LinearLayout.LayoutParams(dp(35),dp(46)));

        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        root.addView(bar); root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);

        address.setOnEditorActionListener((v,a,e)->{ navigate(address.getText().toString()); return true; });
        home.setOnClickListener(v->navigate("https://www.google.com"));
        tabCount.setOnClickListener(v->showTabs());
        menu.setOnClickListener(v->showMenu());
        star.setOnClickListener(v->Toast.makeText(this,"تم حفظ الإشارة المرجعية",Toast.LENGTH_SHORT).show());
    }

    WebView newWebView(){
        WebView w=new WebView(this);
        WebSettings s=w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setSupportMultipleWindows(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadsImagesAutomatically(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        w.setBackgroundColor(Color.BLACK);
        w.setWebViewClient(new WebViewClient(){
            @Override public void onPageStarted(WebView v,String url,android.graphics.Bitmap f){
                address.setText(url); address.setSelection(address.length());
            }
            @Override public void onReceivedSslError(WebView v,SslErrorHandler h,SslError e){
                new AlertDialog.Builder(MainActivity.this).setTitle("تحذير أمني")
                    .setMessage("تعذر التحقق من شهادة أمان الموقع. قد يكون الاتصال غير آمن.")
                    .setNegativeButton("العودة", (d,x)->h.cancel())
                    .setPositiveButton("المتابعة", (d,x)->h.proceed()).show();
            }
        });
        return w;
    }

    void addTab(String url){
        WebView w=newWebView(); tabs.add(w); current=tabs.size()-1;
        content.removeAllViews(); content.addView(w,new LinearLayout.LayoutParams(-1,-1));
        w.loadUrl(url); updateTabs();
    }

    void navigate(String q){
        String u=q.trim();
        if(!u.matches("(?i)^https?://.*")) u="https://www.google.com/search?q="+Uri.encode(u);
        tabs.get(current).loadUrl(u);
    }

    void updateTabs(){ tabCount.setText(String.valueOf(tabs.size())); }

    void showTabs(){
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(12),dp(12),dp(12),dp(12));
        for(int i=0;i<tabs.size();i++){
            final int n=i; TextView t=button((i+1)+". "+tabs.get(i).getTitle());
            t.setGravity(Gravity.CENTER_VERTICAL); t.setTextSize(15);
            t.setOnClickListener(v->{current=n; content.removeAllViews(); content.addView(tabs.get(current),new LinearLayout.LayoutParams(-1,-1)); updateTabs();});
            l.addView(t,new LinearLayout.LayoutParams(-1,dp(52)));
        }
        new AlertDialog.Builder(this).setTitle("علامات التبويب").setView(l)
            .setPositiveButton("علامة تبويب جديدة",(d,w)->addTab("https://www.google.com"))
            .setNegativeButton("إغلاق",null).show();
    }

    void showMenu(){
        String[] items={"إضافات Chrome","علامة تبويب جديدة","التصفح المتخفي","السجل","التنزيل","الإشارات المرجعية","إخفاء الصور والفيديو","منع الإعلانات","عرض سطح المكتب","الوضع الليلي","الإعدادات"};
        new AlertDialog.Builder(this).setItems(items,(d,which)->{
            if(which==1) addTab("https://www.google.com");
            else if(which==2) Toast.makeText(this,"وضع التصفح المتخفي قيد الإعداد",Toast.LENGTH_SHORT).show();
            else if(which==10) Toast.makeText(this,"الإعدادات قيد الإعداد",Toast.LENGTH_SHORT).show();
        }).show();
    }
}
