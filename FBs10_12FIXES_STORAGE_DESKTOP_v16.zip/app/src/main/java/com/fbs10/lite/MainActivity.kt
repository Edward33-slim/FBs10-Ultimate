package com.fbs10.lite

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.net.ConnectivityManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.ValueCallback
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import android.app.Dialog
import com.google.android.material.tabs.TabLayout
import java.io.ByteArrayInputStream

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var prefs: SharedPreferences

    private var isAdsHidden = true
    private var isMediaHidden = true
    private var isSuggestionsHidden = true
    private var desktopMode = false

    private val favorites = mutableListOf<String>()
    private val badgeHandler = Handler(Looper.getMainLooper())
    private val badgeRunnable = object : Runnable {
        override fun run() {
            if (!isFinishing && !isDestroyedCompat()) {
                fetchBadges()
                badgeHandler.postDelayed(this, 15000L)
            }
        }
    }

    private lateinit var btnHideAds: ImageView
    private lateinit var btnHideMedia: ImageView
    private lateinit var btnHideSuggestions: ImageView
    private lateinit var btnAddFavorite: ImageView
    private lateinit var btnShowFavorites: ImageView
    private lateinit var btnDesktop: ImageView
    private lateinit var badgeNotifications: TextView
    private lateinit var badgeMessages: TextView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        requestStorageAccessIfNeeded()

        prefs = getSharedPreferences("fbs10_prefs", Context.MODE_PRIVATE)
        loadPreferences()
        loadFavorites()

        webView = findViewById(R.id.webView)
        btnHideAds = findViewById(R.id.btnHideAds)
        btnHideMedia = findViewById(R.id.btnHideMedia)
        btnHideSuggestions = findViewById(R.id.btnHideSuggestions)
        btnAddFavorite = findViewById(R.id.btnAddFavorite)
        btnShowFavorites = findViewById(R.id.btnShowFavorites)
        btnDesktop = findViewById(R.id.btnDesktop)
        badgeNotifications = findViewById(R.id.badgeNotifications)
        badgeMessages = findViewById(R.id.badgeMessages)

        setupWebView()
        setupControls()
        updateButtonStates()

        if (savedInstanceState == null) {
            webView.loadUrl(getBestFacebookUrl())
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    private fun loadPreferences() {
        isAdsHidden = prefs.getBoolean("hide_ads", true)
        isMediaHidden = prefs.getBoolean("hide_media", true)
        isSuggestionsHidden = prefs.getBoolean("hide_suggestions", true)
        desktopMode = prefs.getBoolean("desktop_mode", false)
    }

    private fun savePreferences() {
        prefs.edit()
            .putBoolean("hide_ads", isAdsHidden)
            .putBoolean("hide_media", isMediaHidden)
            .putBoolean("hide_suggestions", isSuggestionsHidden)
            .putBoolean("desktop_mode", desktopMode)
            .apply()
    }

    private fun loadFavorites() {
        favorites.clear()
        val list = prefs.getString("favorites_list", "")
        if (!list.isNullOrEmpty()) {
            // Backward compatible: old versions stored only URLs.
            list.split("|||").filter { it.isNotEmpty() }.forEach { item ->
                val parts = item.split(":::", limit = 2)
                favorites.add(if (parts.size == 2) item else "Facebook:::${item}")
            }
        }
    }

    private fun saveFavorites() {
        prefs.edit().putString("favorites_list", favorites.joinToString("|||")).apply()
    }

    private fun favoriteName(item: String): String =
        item.split(":::", limit = 2).firstOrNull().orEmpty().ifEmpty { "Facebook" }

    private fun favoriteUrl(item: String): String =
        item.split(":::", limit = 2).getOrNull(1) ?: item

    private fun requestStorageAccessIfNeeded() {
        if (Build.VERSION.SDK_INT in 23..32) {
            val write = android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            if (checkSelfPermission(write) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(write, android.Manifest.permission.READ_EXTERNAL_STORAGE), 2001)
            }
        }
    }

    private fun updateButtonStates() {
        btnHideAds.setColorFilter(if (isAdsHidden) Color.GRAY else Color.WHITE)
        btnHideMedia.setColorFilter(if (isMediaHidden) Color.GRAY else Color.WHITE)
        btnHideSuggestions.setColorFilter(if (isSuggestionsHidden) Color.GRAY else Color.WHITE)
        btnDesktop.setColorFilter(if (desktopMode) Color.WHITE else Color.GRAY)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        if (Build.VERSION.SDK_INT >= 21) cm.setAcceptThirdPartyCookies(webView, true)

        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.cacheMode = WebSettings.LOAD_CACHE_ELSE_NETWORK
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.setSupportMultipleWindows(false)
        s.offscreenPreRaster = false
        s.useWideViewPort = true
        s.loadWithOverviewMode = false
        s.builtInZoomControls = false
        s.displayZoomControls = false
        applyUserAgent(s)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                return interceptResource(view, request.url.toString())
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                injectAll(view ?: webView)
                expandComments(view ?: webView)
                fetchBadges()
            }
        }
        webView.webChromeClient = createChromeClient()
    }

    private fun createChromeClient(): WebChromeClient {
        return object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePath: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = filePath
                return try {
                    val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                        type = "*/*"
                    }
                    intent.addCategory(Intent.CATEGORY_OPENABLE)
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    startActivityForResult(intent, 3001)
                    true
                } catch (e: Exception) {
                    filePathCallback = null
                    false
                }
            }
        }
    }

    @Deprecated("Deprecated in Android API 30; retained for Android 7+ compatibility.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 3001) {
            val callback = filePathCallback
            filePathCallback = null
            if (callback != null) {
                val results = if (resultCode == RESULT_OK && data != null) {
                    val clip = data.clipData
                    when {
                        clip != null -> Array(clip.itemCount) { i -> clip.getItemAt(i).uri }
                        data.data != null -> arrayOf(data.data!!)
                        else -> emptyArray()
                    }
                } else emptyArray()
                callback.onReceiveValue(results)
            }
            return
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    private fun applyUserAgent(settings: WebSettings) {
        settings.userAgentString = if (desktopMode) {
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        } else {
            "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        }
    }

    private fun interceptResource(view: WebView, url: String): WebResourceResponse? {
        val lower = url.lowercase()
        if (lower.contains("doubleclick.net") || lower.contains("googlesyndication")) {
            return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
        }
        // Do not block media at network level. Facebook frequently uses extensionless/CDN URLs.
        // DOM filtering below is more reliable and allows emoji/reaction/sticker assets.
        return null
    }

    private fun setupControls() {
        findViewById<View>(R.id.btnNotifications).setOnClickListener {
            webView.loadUrl(if (desktopMode) "https://www.facebook.com/notifications/" else "https://m.facebook.com/notifications/")
        }

        findViewById<View>(R.id.btnHome).setOnClickListener {
            // The only deliberate refresh button.
            webView.loadUrl(if (desktopMode) "https://www.facebook.com/" else getBestFacebookUrl())
        }

        findViewById<View>(R.id.btnMessenger).setOnClickListener {
            showMessengerDialog()
        }

        btnDesktop.setOnClickListener {
            desktopMode = !desktopMode
            savePreferences()
            updateButtonStates()
            applyUserAgent(webView.settings)
            webView.loadUrl(if (desktopMode) "https://www.facebook.com/" else getBestFacebookUrl())
            Toast.makeText(
                this,
                if (desktopMode) "تم تفعيل عرض سطح المكتب" else "تم إيقاف عرض سطح المكتب",
                Toast.LENGTH_SHORT
            ).show()
        }

        btnHideAds.setOnClickListener {
            isAdsHidden = !isAdsHidden
            savePreferences()
            updateButtonStates()
            injectAds(webView)
            Toast.makeText(
                this,
                if (isAdsHidden) "تم إخفاء الإعلانات والممول" else "تم إظهار الإعلانات والممول",
                Toast.LENGTH_SHORT
            ).show()
        }

        btnHideMedia.setOnClickListener {
            isMediaHidden = !isMediaHidden
            savePreferences()
            updateButtonStates()
            injectMedia(webView)
            // No reload: scrolling or changing this option must not force a refresh.
            Toast.makeText(
                this,
                if (isMediaHidden) "تم إخفاء الصور والفيديو (مع إبقاء الإيموجي واللايكات)" else "تم إظهار الصور والفيديو",
                Toast.LENGTH_SHORT
            ).show()
        }

        btnHideSuggestions.setOnClickListener {
            isSuggestionsHidden = !isSuggestionsHidden
            savePreferences()
            updateButtonStates()
            injectSuggestions(webView)
            Toast.makeText(
                this,
                if (isSuggestionsHidden) "تم إخفاء الاقتراحات والمنشورات غير المتابعة" else "تم إظهار الاقتراحات",
                Toast.LENGTH_SHORT
            ).show()
        }

        btnAddFavorite.setOnClickListener {
            val url = webView.url ?: return@setOnClickListener
            if (url.contains("facebook.com")) {
                if (favorites.none { favoriteUrl(it) == url }) {
                    favorites.add("Facebook:::${url}")
                    saveFavorites()
                    Toast.makeText(this, "تمت إضافة الصفحة إلى المفضلة", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "موجودة بالفعل في المفضلة", Toast.LENGTH_SHORT).show()
                }
            }
        }

        btnShowFavorites.setOnClickListener {
            if (favorites.isEmpty()) {
                Toast.makeText(this, "لا توجد مفضلات", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val labels = favorites.map { favoriteName(it) }.toTypedArray()
            val dialog = AlertDialog.Builder(this)
                .setTitle("المفضلات")
                .setItems(labels) { _, which -> webView.loadUrl(favoriteUrl(favorites[which])) }
                .setNegativeButton("إغلاق", null)
                .create()

            dialog.setOnShowListener {
                val listView = dialog.listView
                listView.setOnItemLongClickListener { _, _, which, _ ->
                    val item = favorites[which]
                    val actions = arrayOf("حذف", "إعادة تسمية")
                    AlertDialog.Builder(this)
                        .setTitle(favoriteName(item))
                        .setItems(actions) { _, action ->
                            when (action) {
                                0 -> {
                                    favorites.removeAt(which)
                                    saveFavorites()
                                    dialog.dismiss()
                                    btnShowFavorites.performClick()
                                }
                                1 -> {
                                    val input = EditText(this)
                                    input.setText(favoriteName(item))
                                    input.selectAll()
                                    AlertDialog.Builder(this)
                                        .setTitle("إعادة تسمية الرابط")
                                        .setView(input)
                                        .setNegativeButton("إلغاء", null)
                                        .setPositiveButton("حفظ") { _, _ ->
                                            val newName = input.text.toString().trim().ifEmpty { "Facebook" }
                                            favorites[which] = "$newName:::${favoriteUrl(item)}"
                                            saveFavorites()
                                            dialog.dismiss()
                                            btnShowFavorites.performClick()
                                        }
                                        .show()
                                }
                            }
                        }.show()
                    true
                }
            }
            dialog.show()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun showMessengerDialog() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_messenger, null)
        dialog.setContentView(view)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)

        val tabLayout = view.findViewById<TabLayout>(R.id.tabLayoutMessages)
        val innerWebView = view.findViewById<WebView>(R.id.innerWebView)
        val innerPrefs = getSharedPreferences("fbs10_messages", Context.MODE_PRIVATE)
        val savedTab = innerPrefs.getInt("tab", 0)

        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        if (Build.VERSION.SDK_INT >= 21) cm.setAcceptThirdPartyCookies(innerWebView, true)

        val s = innerWebView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.cacheMode = WebSettings.LOAD_CACHE_ELSE_NETWORK
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.setSupportMultipleWindows(false)
        s.offscreenPreRaster = false
        s.useWideViewPort = true
        s.loadWithOverviewMode = false
        s.builtInZoomControls = false
        s.displayZoomControls = false
        // Desktop UA is intentional: Facebook's mobile page can show
        // "يجب استخدام Messenger", while the desktop web UI exposes messages.
        s.userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

        innerWebView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = false

            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                return interceptResource(view, request.url.toString())
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                injectMedia(innerWebView)
                expandComments(innerWebView)
                selectMessageCategory(innerWebView, tabLayout.selectedTabPosition)
            }
        }
        innerWebView.webChromeClient = createChromeClient()

        tabLayout.addTab(tabLayout.newTab().setText("الأساسية"))
        tabLayout.addTab(tabLayout.newTab().setText("الطلبات"))
        tabLayout.addTab(tabLayout.newTab().setText("غير مهم"))
        tabLayout.getTabAt(savedTab.coerceIn(0, 2))?.select()

        tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                val pos = tab?.position ?: 0
                innerPrefs.edit().putInt("tab", pos).apply()
                selectMessageCategory(innerWebView, pos)
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {
                selectMessageCategory(innerWebView, tab?.position ?: 0)
            }
        })

        view.findViewById<ImageView>(R.id.btnMessengerSettings).setOnClickListener {
            innerWebView.loadUrl("https://www.facebook.com/messages/e2ee/t/")
        }

        // Desktop Facebook Messages page, matching the useful behavior
        // observed in Kiwi Browser desktop mode.
        innerWebView.loadUrl("https://www.facebook.com/messages/e2ee/t/")
        view.findViewById<ImageView>(R.id.btnMessengerBack).setOnClickListener { dialog.dismiss() }
        dialog.setOnShowListener {
            dialog.window?.setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT
            )
        }
        dialog.show()
    }

    private fun selectMessageCategory(web: WebView, position: Int) {
        val label = when (position) {
            1 -> "طلبات"
            2 -> "غير مهم"
            else -> "الأساسية"
        }
        val js = """
            (function(){
              var target='$label';
              var nodes=document.querySelectorAll('[role="tab"],[role="button"],a,span,div');
              for(var i=0;i<nodes.length;i++){
                var t=(nodes[i].innerText||nodes[i].textContent||'').trim();
                if(t===target){try{nodes[i].click();return true;}catch(e){}}
              }
              return false;
            })();
        """.trimIndent()
        web.evaluateJavascript(js, null)
    }

    private fun injectAll(target: WebView) {
        injectMedia(target)
        injectAds(target)
        injectSuggestions(target)
        injectPullToRefreshBlock(target)
        injectPenButtonHide(target)
    }

    private fun injectPullToRefreshBlock(target: WebView) {
        val js = """
            (function(){
              if(window.__fbs10PullBlock) return;
              window.__fbs10PullBlock=true;
              var sy=0;
              document.addEventListener('touchstart',function(e){
                if(e.touches&&e.touches.length===1) sy=e.touches[0].clientY;
              },{passive:true,capture:true});
              document.addEventListener('touchmove',function(e){
                if(!e.touches||e.touches.length!==1) return;
                var dy=e.touches[0].clientY-sy;
                var se=document.scrollingElement||document.documentElement;
                if(dy>12 && se.scrollTop<=0){ e.preventDefault(); }
              },{passive:false,capture:true});
            })();
        """.trimIndent()
        target.evaluateJavascript(js, null)
    }

    private fun injectPenButtonHide(target: WebView) {
        val js = """
            (function(){
              function apply(){
                var nodes=document.querySelectorAll('[aria-label],[role="button"],button');
                nodes.forEach(function(el){
                  var t=((el.getAttribute('aria-label')||'')+' '+(el.getAttribute('title')||'')+' '+(el.innerText||'')).toLowerCase();
                  if(/create post|إنشاء منشور|كتابة منشور|compose|قلم|مؤلف/.test(t)){
                    var r=el.getBoundingClientRect();
                    if(r.width<100 && r.height<100 && r.bottom>window.innerHeight-180){
                      el.style.setProperty('display','none','important');
                      el.setAttribute('data-fbs10-pen','1');
                    }
                  }
                });
              }
              apply();
              if(!window.__fbs10PenObserver){
                window.__fbs10PenObserver=new MutationObserver(function(){clearTimeout(window.__fbs10PenTimer);window.__fbs10PenTimer=setTimeout(apply,500);});
                window.__fbs10PenObserver.observe(document.documentElement,{childList:true,subtree:true});
              }
            })();
        """.trimIndent()
        target.evaluateJavascript(js, null)
    }

    private fun injectMedia(target: WebView) {
        val hide = if (isMediaHidden) "true" else "false"
        val js = """
            (function(){
              var hide=$hide;
              function isKeep(el){
                var s=((el.currentSrc||el.src||'')+' '+(el.getAttribute('aria-label')||'')+' '+(el.getAttribute('alt')||'')+' '+(el.className||'')).toLowerCase();
                var parent=((el.parentElement&&el.parentElement.innerText)||'').toLowerCase();
                return /emoji|emoticon|reaction|react|sticker|like|icon|smiley|gif/.test(s)
                    || /emoji|ملصق|تفاعل|اعجاب|إعجاب|رمز تعبيري|لايك/.test(s+' '+parent);
              }
              function apply(){
                document.querySelectorAll('img,video,picture,source,canvas').forEach(function(el){
                  if(isKeep(el)){
                    el.style.removeProperty('display');
                    return;
                  }
                  if(hide){
                    el.style.setProperty('display','none','important');
                    el.setAttribute('data-fbs10-media','1');
                  }else if(el.getAttribute('data-fbs10-media')){
                    el.style.removeProperty('display');
                    el.removeAttribute('data-fbs10-media');
                  }
                });
              }
              apply();
              if(!window.__fbs10MediaObserver){
                window.__fbs10MediaObserver=new MutationObserver(function(){clearTimeout(window.__fbs10MediaTimer);window.__fbs10MediaTimer=setTimeout(apply,300);});
                window.__fbs10MediaObserver.observe(document.documentElement,{childList:true,subtree:true,attributes:true,attributeFilter:['src','class','alt','aria-label']});
              }
            })();
        """.trimIndent()
        target.evaluateJavascript(js, null)
    }

    private fun injectAds(target: WebView) {
        val hide = if (isAdsHidden) "true" else "false"
        val js = """
            (function(){
              var hide=$hide;
              var keys=['ممول','إعلان','إعلانات','Sponsored','Promoted','Paid partnership'];
              function apply(){
                document.querySelectorAll('[role="article"],article,section').forEach(function(el){
                  var text=(el.innerText||'').trim();
                  if(!text || text.length>2500) return;
                  var found=keys.some(function(k){return text.indexOf(k)>=0;});
                  if(found){
                    var p=el.closest('[role="article"]')||el;
                    if(hide){p.style.setProperty('display','none','important');p.setAttribute('data-fbs10-ads','1');}
                    else{p.style.removeProperty('display');p.removeAttribute('data-fbs10-ads');}
                  }
                });
              }
              apply();
              if(!window.__fbs10AdsObserver){
                window.__fbs10AdsObserver=new MutationObserver(function(){clearTimeout(window.__fbs10AdsTimer);window.__fbs10AdsTimer=setTimeout(apply,400);});
                window.__fbs10AdsObserver.observe(document.documentElement,{childList:true,subtree:true});
              }
            })();
        """.trimIndent()
        target.evaluateJavascript(js, null)
    }

    private fun injectSuggestions(target: WebView) {
        val hide = if (isSuggestionsHidden) "true" else "false"
        val js = """
            (function(){
              var hide=$hide;
              var keys=[
                'اقتراحات قد تعجبك','قد تعجبك','أشخاص قد تعرفهم','ريلز','Reels',
                'قصص','Stories','صفحات قد تعجبك','Suggested for you',
                'اقتراحات','المجموعات التي قد تعجبك'
              ];
              function hasVerified(el){
                var s=((el.getAttribute('aria-label')||'')+' '+(el.getAttribute('title')||'')+' '+(el.className||'')).toLowerCase();
                return /verified|موثّق|موثق|تم التحقق/.test(s) ||
                  !!el.querySelector('[aria-label*="Verified"],[aria-label*="موث"],svg[aria-label*="Verified"]');
              }
              function hasUnfollowedAccount(el){
                var t=(el.innerText||'').trim();
                return /(^|\\n)متابعة(\\s|$)/.test(t) || /(^|\\n)Follow(\\s|$)/.test(t);
              }
              function hasUnfollowedGroup(el){
                var t=(el.innerText||'').trim();
                return /(^|\\n)(انضمام|Join)(\\s|$)/.test(t) && /(^|\\n)(مجموعة|Group)(\\s|$)/i.test(t);
              }
              function apply(){
                document.querySelectorAll('[role="article"],article,section').forEach(function(el){
                  var text=(el.innerText||'').trim();
                  if(!text || text.length>3500) return;
                  var found=keys.some(function(k){return text.indexOf(k)>=0;});
                  var hideUnfollowed=hasUnfollowedAccount(el)||hasUnfollowedGroup(el);
                  var hideVerified=hasVerified(el);
                  if(found||hideUnfollowed||hideVerified){
                    var p=el.closest('[role="article"]')||el;
                    if(hide){
                      p.style.setProperty('display','none','important');
                      p.setAttribute('data-fbs10-sug','1');
                    }else if(p.getAttribute('data-fbs10-sug')){
                      p.style.removeProperty('display');
                      p.removeAttribute('data-fbs10-sug');
                    }
                  }
                });
              }
              apply();
              if(!window.__fbs10SugObserver){
                window.__fbs10SugObserver=new MutationObserver(function(){clearTimeout(window.__fbs10SugTimer);window.__fbs10SugTimer=setTimeout(apply,450);});
                window.__fbs10SugObserver.observe(document.documentElement,{childList:true,subtree:true});
              }
            })();
        """.trimIndent()
        target.evaluateJavascript(js, null)
        // Ads are also a recommendation/noise category, so the suggestion
        // switch reinforces the ad filter without removing the separate ad switch.
        if (isSuggestionsHidden) injectAds(target)
    }

    private fun expandComments(target: WebView) {
        val js = """
            (function(){
              function clickMore(){
                var keys=[
                  'عرض المزيد من التعليقات','عرض المزيد','عرض التعليقات السابقة',
                  'عرض المزيد من الردود','View more comments','View more replies',
                  'View previous comments','View more'
                ];
                var nodes=document.querySelectorAll('[role="button"],button,a,span');
                for(var i=0;i<nodes.length;i++){
                  var t=(nodes[i].innerText||nodes[i].textContent||'').trim();
                  if(t && t.length<120 && keys.some(function(k){return t.indexOf(k)>=0;})){
                    try{nodes[i].click();}catch(e){}
                  }
                }
              }
              clickMore();
              if(!window.__fbs10CommentsObserver){
                window.__fbs10CommentsObserver=new MutationObserver(function(){clearTimeout(window.__fbs10CommentsTimer);window.__fbs10CommentsTimer=setTimeout(clickMore,500);});
                window.__fbs10CommentsObserver.observe(document.documentElement,{childList:true,subtree:true});
              }
            })();
        """.trimIndent()
        target.evaluateJavascript(js, null)
    }

    private fun fetchBadges() {
        val js = """
            (function(){
              function unread(selector, words){
                var nodes=document.querySelectorAll(selector);
                for(var i=0;i<nodes.length;i++){
                  var e=nodes[i];
                  var a=((e.getAttribute('aria-label')||'')+' '+(e.getAttribute('title')||'')+' '+(e.innerText||'')).toLowerCase();
                  if(words.some(function(w){return a.indexOf(w)>=0;})){
                    var n=a.match(/\\b([1-9][0-9]*)\\b/);
                    if(n) return parseInt(n[1],10);
                    if(/unread|new|غير مقروء|جديد|إشعار|رسالة/.test(a)) return 1;
                  }
                }
                return 0;
              }
              return unread('a,[role="button"],[aria-label]', ['notifications','إشعارات','الإشعارات']);
            })();
        """.trimIndent()
        webView.evaluateJavascript(js) { value ->
            setDot(badgeNotifications, value.replace("\"","").toIntOrNull() ?: 0)
        }

        val jsMsg = """
            (function(){
              var nodes=document.querySelectorAll('a,[role="button"],[aria-label]');
              for(var i=0;i<nodes.length;i++){
                var e=nodes[i];
                var a=((e.getAttribute('aria-label')||'')+' '+(e.getAttribute('title')||'')+' '+(e.innerText||'')).toLowerCase();
                if(/messenger|messages|الرسائل|رسائل/.test(a) &&
                   /unread|new|غير مقروء|جديد|رسالة/.test(a)) return 1;
              }
              return 0;
            })();
        """.trimIndent()
        webView.evaluateJavascript(jsMsg) { value ->
            setDot(badgeMessages, value.replace("\"","").toIntOrNull() ?: 0)
        }
    }

    private fun setDot(view: TextView, value: Int) {
        view.visibility = if (value > 0) View.VISIBLE else View.GONE
        view.text = ""
    }

    private fun getBestFacebookUrl(): String {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val slow = caps?.let { it.linkDownstreamBandwidthKbps < 600 } ?: true
        return if (slow) "https://mbasic.facebook.com/home.php" else "https://m.facebook.com/home.php"
    }

    override fun onResume() {
        super.onResume()
        badgeHandler.removeCallbacks(badgeRunnable)
        badgeHandler.post(badgeRunnable)
    }

    override fun onPause() {
        badgeHandler.removeCallbacks(badgeRunnable)
        super.onPause()
    }

    private fun isDestroyedCompat(): Boolean =
        Build.VERSION.SDK_INT >= 17 && isDestroyed

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }
}
