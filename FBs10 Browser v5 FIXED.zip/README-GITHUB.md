# FBs10 Browser

This repository is an Android Studio/Gradle project. The Android project files must be
in the repository root (or inside a single nested folder; the GitHub Actions workflow
automatically locates `settings.gradle`).

Build workflow:
- `.github/workflows/build-apk.yml`
- GitHub Actions -> Build FBs10 Browser APK
- The generated APK is uploaded as the `FBs10-Browser-APK` artifact.

Pinch-to-zoom is enabled in the WebView with built-in zoom controls hidden from the UI.
