          package com.fbs10.lite

          import android.annotation.SuppressLint
          import android.content.Context
          import android.content.SharedPreferences
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
          import android.graphics.Color
          import android.net.ConnectivityManager
          import android.os.Build
          import android.os.Bundle
import android.os.Handler
import android.os.Looper
          import android.view.View
import android.view.LayoutInflater
          import android.webkit.WebChromeClient
          import android.webkit.WebResourceRequest
import android.webkit.WebResourceError
          import android.webkit.WebResourceResponse
          import android.webkit.WebView
import android.webkit.WebSettings
import android.webkit.ValueCallback
import android.webkit.WebChromeClient.FileChooserParams
import android.webkit.CookieManager
          import android.webkit.WebViewClient
          import android.widget.ImageView
          import android.widget.TextView
          import android.widget.Toast
          import androidx.appcompat.app.AlertDialog
          import androidx.appcompat.app.AppCompatActivity
          import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
          import com.google.android.material.bottomsheet.BottomSheetDialog
          import com.google.android.material.tabs.TabLayout
          import java.io.ByteArrayInputStream

          class MainActivity : AppCompatActivity() {

              private lateinit var webView: WebView
              private lateinit var swipeRefresh: SwipeRefreshLayout
              private lateinit var prefs: SharedPreferences

              private var isAdsHidden = true
              private var isMediaHidden = true
              private var isSuggestionsHidden = true
              private var hideSuggestedGroups = true
              private var hideVerifiedPosts = true
              private var hideReels = true
              private var hideStories = true
              private var hidePeopleYouMayKnow = true
              private var hidePagesYouMayLike = true
              private var hideSponsored = true
              private var hideUnknownSuggestedPosts = true
              private var filePathCallback: ValueCallback<Array<Uri>>? = null
              private val FILE_CHOOSER_REQUEST = 4001
              private var commentsExpandUntil = 0L
              private var currentTheme = "light"

              private val favorites = mutableListOf<String>()
              private val badgeHandler = Handler(Looper.getMainLooper())
              private val badgeRunnable = object : Runnable {
                  override fun run() {
                      if (!isFinishing && !isDestroyedCompat()) {
                          fetchBadges()
                          badgeHandler.postDelayed(this, 30000L)
                      }
                  }
              }

              private lateinit var btnHideAds: ImageView
              private lateinit var btnHideMedia: ImageView
              private lateinit var btnHideSuggestions: ImageView
              private lateinit var btnTheme: ImageView
              private lateinit var btnAddFavorite: ImageView
              private lateinit var btnShowFavorites: ImageView
              private lateinit var badgeNotifications: TextView
              private lateinit var badgeMessages: TextView

              @SuppressLint("SetJavaScriptEnabled")
              override fun onCreate(savedInstanceState: Bundle?) {
                  super.onCreate(savedInstanceState)
                  setContentView(R.layout.activity_main)

                  prefs = getSharedPreferences("fbs10_prefs", Context.MODE_PRIVATE)
                  loadPreferences()
                  loadFavorites()

                  webView = findViewById(R.id.webView)
                  swipeRefresh = findViewById(R.id.swipeRefresh)

                  btnHideAds = findViewById(R.id.btnHideAds)
                  btnHideMedia = findViewById(R.id.btnHideMedia)
                  btnHideSuggestions = findViewById(R.id.btnHideSuggestions)
                  btnTheme = findViewById(R.id.btnTheme)
                  btnAddFavorite = findViewById(R.id.btnAddFavorite)
                  btnShowFavorites = findViewById(R.id.btnShowFavorites)
                  badgeNotifications = findViewById(R.id.badgeNotifications)
                  badgeMessages = findViewById(R.id.badgeMessages)

                  setupWebView()
                  setupControls()
                  updateButtonStates()

                  webView.loadUrl(getBestFacebookUrl())
              }

              private fun loadPreferences() {
                  isAdsHidden = prefs.getBoolean("hide_ads", true)
                  isMediaHidden = prefs.getBoolean("hide_media", true)
                  isSuggestionsHidden = prefs.getBoolean("hide_suggestions", true)
                  hideSuggestedGroups = prefs.getBoolean("hide_suggested_groups", true)
                  hideVerifiedPosts = prefs.getBoolean("hide_verified_posts", true)
                  hideReels = prefs.getBoolean("hide_reels", true)
                  hideStories = prefs.getBoolean("hide_stories", true)
                  hidePeopleYouMayKnow = prefs.getBoolean("hide_people_you_may_know", true)
                  hidePagesYouMayLike = prefs.getBoolean("hide_pages_you_may_like", true)
                  hideSponsored = prefs.getBoolean("hide_sponsored", true)
                  hideUnknownSuggestedPosts = prefs.getBoolean("hide_unknown_suggested_posts", true)
                  currentTheme = prefs.getString("theme", "light") ?: "light"
              }

              private fun savePreferences() {
                  prefs.edit().apply {
                      putBoolean("hide_ads", isAdsHidden)
                      putBoolean("hide_media", isMediaHidden)
                      putBoolean("hide_suggestions", isSuggestionsHidden)
                      putBoolean("hide_suggested_groups", hideSuggestedGroups)
                      putBoolean("hide_verified_posts", hideVerifiedPosts)
                      putBoolean("hide_reels", hideReels)
                      putBoolean("hide_stories", hideStories)
                      putBoolean("hide_people_you_may_know", hidePeopleYouMayKnow)
                      putBoolean("hide_pages_you_may_like", hidePagesYouMayLike)
                      putBoolean("hide_sponsored", hideSponsored)
                      putBoolean("hide_unknown_suggested_posts", hideUnknownSuggestedPosts)
                      putString("theme", currentTheme)
                      apply()
                  }
              }

              private fun loadFavorites() {
                  favorites.clear()
                  val list = prefs.getString("favorites_list", "")
                  if (!list.isNullOrEmpty()) {
                      favorites.addAll(list.split("|||").filter { it.isNotEmpty() })
                  }
              }

              private fun saveFavorites() {
                  prefs.edit().putString("favorites_list", favorites.joinToString("|||")).apply()
              }

              private fun updateButtonStates() {
                  btnHideAds.setColorFilter(if (isAdsHidden) Color.GRAY else Color.WHITE)
                  btnHideMedia.setColorFilter(if (isMediaHidden) Color.GRAY else Color.WHITE)
                  btnHideSuggestions.setColorFilter(if (isSuggestionsHidden) Color.GRAY else Color.WHITE)
                  btnTheme.setColorFilter(if (currentTheme == "dark") Color.BLACK else Color.WHITE)
              }

              @SuppressLint("SetJavaScriptEnabled")
              private fun setupWebView() {
                  val cookieManager = CookieManager.getInstance()
                  cookieManager.setAcceptCookie(true)
                  if (Build.VERSION.SDK_INT >= 21) cookieManager.setAcceptThirdPartyCookies(webView, true)

                  val s = webView.settings
                  s.javaScriptEnabled = true
                  s.domStorageEnabled = true
                  s.databaseEnabled = true
                  s.cacheMode = WebSettings.LOAD_CACHE_ELSE_NETWORK
                  s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                  s.useWideViewPort = true
                  s.loadWithOverviewMode = true
                  s.allowFileAccess = true
                  s.allowContentAccess = true
                  s.javaScriptCanOpenWindowsAutomatically = false
                  s.setSupportMultipleWindows(false)
                  s.userAgentString = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                  webView.setLayerType(View.LAYER_TYPE_HARDWARE, null)

                  webView.webViewClient = object : WebViewClient() {
                      override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                          return handleSpecialUrl(view, request.url.toString())
                      }

                      @Suppress("DEPRECATION")
                      override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                          return handleSpecialUrl(view, url)
                      }

                      override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                          val url = request.url.toString()
                          if (url.contains("doubleclick.net") || url.contains("googlesyndication") ||
                              url.contains("googleadservices.com")) {
                              return WebResourceResponse("text/plain", "utf-8",
                                  ByteArrayInputStream(ByteArray(0)))
                          }

                          if (isMediaHidden && isMediaResource(url)) {
                              val lower = url.lowercase()
                              if (!lower.contains("emoji") && !lower.contains("reaction") &&
                                  !lower.contains("sticker") && !lower.contains("icon") &&
                                  !lower.contains("avatar")) {
                                  return WebResourceResponse("text/plain", "utf-8",
                                      ByteArrayInputStream(ByteArray(0)))
                              }
                          }
                          return super.shouldInterceptRequest(view, request)
                      }

                      override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                          super.onPageStarted(view, url, favicon)
                          swipeRefresh.isRefreshing = false
                      }

                      override fun onPageFinished(view: WebView?, url: String?) {
                          super.onPageFinished(view, url)
                          swipeRefresh.isRefreshing = false
                          injectAll()
                          fetchBadges()
                          expandComments()
                      }

                      override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                          super.onReceivedError(view, request, error)
                          swipeRefresh.isRefreshing = false
                      }
                  }

                  webView.webChromeClient = object : WebChromeClient() {
                      override fun onShowFileChooser(
                          webView: WebView?,
                          filePathCallback: ValueCallback<Array<Uri>>?,
                          fileChooserParams: FileChooserParams?
                      ): Boolean {
                          this@MainActivity.filePathCallback?.onReceiveValue(null)
                          this@MainActivity.filePathCallback = filePathCallback

                          if (Build.VERSION.SDK_INT < 33 &&
                              checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                              requestPermissions(arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE), FILE_CHOOSER_REQUEST)
                          }

                          val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                              addCategory(Intent.CATEGORY_OPENABLE)
                              type = "*/*"
                              putExtra(Intent.EXTRA_ALLOW_MULTIPLE, fileChooserParams?.mode == FileChooserParams.MODE_OPEN_MULTIPLE)

                              val accept = fileChooserParams?.acceptTypes
                                  ?.flatMap { it.split(",") }
                                  ?.map { it.trim() }
                                  ?.filter { it.isNotEmpty() }
                                  ?: emptyList()

                              if (accept.size == 1 && accept[0] != "*/*") {
                                  type = accept[0]
                              } else if (accept.isNotEmpty()) {
                                  putExtra(Intent.EXTRA_MIME_TYPES, accept.toTypedArray())
                              }
                          }

                          return try {
                              startActivityForResult(intent, FILE_CHOOSER_REQUEST)
                              true
                          } catch (e: Exception) {
                              this@MainActivity.filePathCallback?.onReceiveValue(null)
                              this@MainActivity.filePathCallback = null
                              false
                          }
                      }
                  }

                  // Pull-to-refresh is intentionally disabled: scrolling must never reload Facebook.
                  swipeRefresh.isEnabled = false
              }

              private fun isMediaResource(url: String): Boolean {
                  val u = url.lowercase()
                  return u.contains(".jpg") || u.contains(".jpeg") || u.contains(".png") ||
                      u.contains(".webp") || u.contains(".gif") || u.contains(".avif") ||
                      u.contains(".mp4") || u.contains(".m4v") || u.contains(".mov") ||
                      u.contains("video") || u.contains("/photo.php") || u.contains("/picture")
              }

              private fun handleSpecialUrl(view: WebView, rawUrl: String): Boolean {
                  val url = rawUrl.trim()
                  if (url.startsWith("http://") || url.startsWith("https://")) return false

                  if (url.startsWith("intent://")) {
                      val fallback = extractIntentFallback(url)
                      if (!fallback.isNullOrEmpty()) {
                          view.loadUrl(fallback)
                      } else {
                          view.loadUrl("https://m.facebook.com/messages/")
                      }
                      return true
                  }

                  if (url.startsWith("fb-messenger://") || url.startsWith("messenger://") ||
                      url.startsWith("fb://")) {
                      view.loadUrl("https://m.facebook.com/messages/")
                      return true
                  }

                  // Do not let unsupported schemes kill the WebView with ERR_UNKNOWN_URL_SCHEME.
                  if (url.contains("://")) {
                      view.loadUrl("https://m.facebook.com/messages/")
                      return true
                  }
                  return false
              }

              private fun extractIntentFallback(intentUrl: String): String? {
                  return try {
                      val key = "S.browser_fallback_url="
                      val start = intentUrl.indexOf(key)
                      if (start < 0) return null
                      var value = intentUrl.substring(start + key.length)
                      val end = value.indexOf(";end")
                      if (end >= 0) value = value.substring(0, end)
                      Uri.decode(value).takeIf { it.startsWith("http://") || it.startsWith("https://") }
                  } catch (_: Exception) {
                      null
                  }
              }

              private fun setupControls() {
                  btnHideAds.setOnClickListener {
                      isAdsHidden = !isAdsHidden
                      savePreferences()
                      updateButtonStates()
                      injectAds()
                      Toast.makeText(this, if (isAdsHidden) "تم حجب الإعلانات" else "إظهار الإعلانات", Toast.LENGTH_SHORT).show()
                  }

                  btnHideMedia.setOnClickListener {
                      isMediaHidden = !isMediaHidden
                      savePreferences()
                      updateButtonStates()
                      injectMedia()
                      Toast.makeText(this, if (isMediaHidden) "تم حجب الصور والفيديو" else "إظهار الصور والفيديو", Toast.LENGTH_SHORT).show()
                  }

                  btnHideSuggestions.setOnClickListener {
                      showContentFilterDialog()
                  }

                  btnTheme.setOnClickListener {
                      currentTheme = if (currentTheme == "light") "dark" else "light"
                      savePreferences()
                      updateButtonStates()
                      injectTheme()
                      Toast.makeText(this, if (currentTheme == "dark") "الوضع الليلي" else "الوضع العادي", Toast.LENGTH_SHORT).show()
                  }

                  btnAddFavorite.setOnClickListener {
                      val url = webView.url ?: return@setOnClickListener
                      if (url.contains("m.facebook.com") || url.contains("mbasic.facebook.com")) {
                          if (!favorites.contains(url)) {
                              favorites.add(url)
                              saveFavorites()
                              Toast.makeText(this, "تمت إضافة المنشور إلى المفضلة", Toast.LENGTH_SHORT).show()
                          } else {
                              Toast.makeText(this, "موجود بالفعل في المفضلة", Toast.LENGTH_SHORT).show()
                          }
                      } else {
                          Toast.makeText(this, "يرجى فتح منشور أولاً", Toast.LENGTH_SHORT).show()
                      }
                  }

                  btnShowFavorites.setOnClickListener {
                      if (favorites.isEmpty()) {
                          Toast.makeText(this, "لا توجد مفضلات", Toast.LENGTH_SHORT).show()
                          return@setOnClickListener
                      }
                      val items = favorites.toTypedArray()
                      AlertDialog.Builder(this)
                          .setTitle("المفضلات")
                          .setItems(items) { _, which ->
                              webView.loadUrl(items[which])
                          }
                          .setNegativeButton("إغلاق", null)
                          .show()
                  }

                  findViewById<View>(R.id.btnNotifications).setOnClickListener {
                      webView.loadUrl("https://m.facebook.com/notifications/")
                  }

                  findViewById<View>(R.id.btnMessenger).setOnClickListener {
                      showMessengerDialog()
                  }
              }

              @SuppressLint("SetJavaScriptEnabled")
              private fun showMessengerDialog() {
                  val dialog = BottomSheetDialog(this)
                  val view = LayoutInflater.from(this).inflate(R.layout.dialog_messenger, null)
                  dialog.setContentView(view)

                  val tabLayout = view.findViewById<TabLayout>(R.id.tabLayoutMessages)
                  val innerWebView = view.findViewById<WebView>(R.id.innerWebView)
                  val innerPrefs = getSharedPreferences("fbs10_messages", Context.MODE_PRIVATE)
                  val savedTab = innerPrefs.getInt("tab", 0)

                  val cm = CookieManager.getInstance()
                  cm.setAcceptCookie(true)
                  if (Build.VERSION.SDK_INT >= 21) cm.setAcceptThirdPartyCookies(innerWebView, true)
                  val s = innerWebView.settings
                  s.javaScriptEnabled = true
                  s.domStorageEnabled = true
                  s.databaseEnabled = true
                  s.cacheMode = WebSettings.LOAD_CACHE_ELSE_NETWORK
                  s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                  s.useWideViewPort = true
                  s.loadWithOverviewMode = true
                  s.builtInZoomControls = false
                  s.displayZoomControls = false
                  s.userAgentString = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"

                  innerWebView.webViewClient = object : WebViewClient() {
                      override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                          val u = request?.url?.toString() ?: return false
                          if (u.startsWith("intent://") || u.startsWith("fb-messenger://") || u.startsWith("messenger://")) {
                              innerWebView.loadUrl(extractIntentFallback(u) ?: "https://m.facebook.com/messages/")
                              return true
                          }
                          return false
                      }
                      @Suppress("DEPRECATION")
                      override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                          val u = url ?: return false
                          if (u.startsWith("intent://") || u.startsWith("fb-messenger://") || u.startsWith("messenger://")) {
                              innerWebView.loadUrl(extractIntentFallback(u) ?: "https://m.facebook.com/messages/")
                              return true
                          }
                          return false
                      }
                      override fun onPageFinished(view: WebView?, url: String?) {
                          super.onPageFinished(view, url)
                          selectMessageCategory(innerWebView, tabLayout.selectedTabPosition)
                          updateMessageTabBadges(innerWebView, tabLayout)
                      }
                  }
                  innerWebView.webChromeClient = WebChromeClient()

                  tabLayout.addTab(tabLayout.newTab().setText("الأساسية"))
                  tabLayout.addTab(tabLayout.newTab().setText("الطلبات"))
                  tabLayout.addTab(tabLayout.newTab().setText("غير مهم"))
                  tabLayout.getTabAt(savedTab.coerceIn(0, 2))?.select()

                  tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
                      override fun onTabSelected(tab: TabLayout.Tab?) {
                          val pos = tab?.position ?: 0
                          innerPrefs.edit().putInt("tab", pos).apply()
                          selectMessageCategory(innerWebView, pos)
                          updateMessageTabBadges(innerWebView, tabLayout)
                      }
                      override fun onTabUnselected(tab: TabLayout.Tab?) {}
                      override fun onTabReselected(tab: TabLayout.Tab?) {
                          selectMessageCategory(innerWebView, tab?.position ?: 0)
                      }
                  })

                  view.findViewById<ImageView>(R.id.btnMessengerSettings).setOnClickListener {
                      innerWebView.loadUrl("https://m.facebook.com/messages/")
                  }

                  cm.flush()
                  innerWebView.loadUrl("https://m.facebook.com/messages/")
                  dialog.show()
              }

              private fun selectMessageCategory(web: WebView, position: Int) {
                  val label = when (position) {
                      1 -> "طلبات"
                      2 -> "غير مهم"
                      else -> "الأساسية"
                  }
                  val js = """
                      (function(){
                        var target='$label';
                        var nodes=document.querySelectorAll('[role="tab"], [role="button"], a, span, div');
                        for(var i=0;i<nodes.length;i++){
                          var t=(nodes[i].innerText||nodes[i].textContent||'').trim();
                          if(t===target){ try{nodes[i].click(); return true;}catch(e){} }
                        }
                        return false;
                      })();
                  """.trimIndent()
                  web.evaluateJavascript(js, null)
              }

              private fun updateMessageTabBadges(web: WebView, tabs: TabLayout) {
                  val js = """
                    (function(){
                      var out=[0,0,0];
                      var labels=['الأساسية','طلبات','غير مهم'];
                      var nodes=document.querySelectorAll('[role="tab"], [role="button"], a, span, div');
                      for(var i=0;i<nodes.length;i++){
                        var t=(nodes[i].innerText||nodes[i].textContent||'').trim();
                        for(var j=0;j<labels.length;j++) if(t.indexOf(labels[j])>=0){
                          var txt=(nodes[i].parentElement?nodes[i].parentElement.innerText:'')||'';
                          var m=txt.match(/\\b(\\d{1,4})\\b/); if(m) out[j]=parseInt(m[1],10);
                        }
                      }
                      return out.join('|');
                    })();
                  """.trimIndent()
                  web.evaluateJavascript(js) { value ->
                      val parts = value.replace("\"", "").split("|")
                      val labels = listOf("الأساسية", "الطلبات", "غير مهم")
                      labels.forEachIndexed { i, label ->
                          val n = parts.getOrNull(i)?.toIntOrNull() ?: 0
                          tabs.getTabAt(i)?.text = if (n > 0) "$label  $n" else label
                      }
                  }
              }

              private fun showContentFilterDialog() {
                  val labels = arrayOf(
                      "إخفاء الإعلانات والممول",
                      "إخفاء اقتراحات قد تعجبك",
                      "إخفاء أشخاص قد تعرفهم",
                      "إخفاء ريلز",
                      "إخفاء القصص",
                      "إخفاء صفحات قد تعجبك",
                      "إخفاء منشورات المجموعات التي لا أتابعها",
                      "إخفاء المنشورات التي بجانب اسمها علامة التوثيق الزرقاء",
                      "إخفاء المنشورات المقترحة الأخرى"
                  )
                  val values = booleanArrayOf(
                      hideSponsored,
                      isSuggestionsHidden,
                      hidePeopleYouMayKnow,
                      hideReels,
                      hideStories,
                      hidePagesYouMayLike,
                      hideSuggestedGroups,
                      hideVerifiedPosts,
                      hideUnknownSuggestedPosts
                  )

                  AlertDialog.Builder(this)
                      .setTitle("إخفاء المحتوى")
                      .setMultiChoiceItems(labels, values) { _, which, checked ->
                          when (which) {
                              0 -> hideSponsored = checked
                              1 -> isSuggestionsHidden = checked
                              2 -> hidePeopleYouMayKnow = checked
                              3 -> hideReels = checked
                              4 -> hideStories = checked
                              5 -> hidePagesYouMayLike = checked
                              6 -> hideSuggestedGroups = checked
                              7 -> hideVerifiedPosts = checked
                              8 -> hideUnknownSuggestedPosts = checked
                          }
                      }
                      .setPositiveButton("تطبيق") { _, _ ->
                          savePreferences()
                          updateButtonStates()
                          injectAll()
                      }
                      .setNegativeButton("إلغاء", null)
                      .show()
              }

              private fun injectAll() {
                  injectMedia()
                  injectAds()
                  injectSuggestions()
                  injectTheme()
              }

              private fun injectMedia() {
                  val hide = isMediaHidden
                  val js = """
                      (function(){
                        var hide=$hide;
                        var style=document.getElementById('fbs10-media-style');
                        if(hide){
                          if(!style){
                            style=document.createElement('style'); style.id='fbs10-media-style';
                            document.head.appendChild(style);
                          }
                          style.textContent='img:not([aria-label*="emoji"]):not([aria-label*="reaction"]):not([aria-label*="sticker"]),video,picture,source{display:none!important;}';
                        }else if(style){style.remove();}
                        document.querySelectorAll('img,video,picture,source').forEach(function(el){
                          var s=(el.currentSrc||el.src||'').toLowerCase();
                          var a=(el.getAttribute('aria-label')||'').toLowerCase();
                          var c=(el.className||'').toString().toLowerCase();
                          if(/emoji|reaction|sticker|icon/.test(s+' '+a+' '+c)) return;
                          if(hide){el.style.setProperty('display','none','important');}
                        });
                        if(hide && !window.__fbs10MediaObserver){
                          window.__fbs10MediaObserver=new MutationObserver(function(){
                            document.querySelectorAll('img,video,picture,source').forEach(function(el){
                              var a=(el.getAttribute('aria-label')||'').toLowerCase(), c=(el.className||'').toString().toLowerCase();
                              if(!/emoji|reaction|sticker|icon/.test(a+' '+c)) el.style.setProperty('display','none','important');
                            });
                          });
                          window.__fbs10MediaObserver.observe(document.documentElement,{subtree:true,childList:true});
                        }
                      })();
                  """.trimIndent()
                  webView.evaluateJavascript(js, null)
              }

              private fun injectAds() {
                  val hide = hideSponsored
                  val js = """
                      (function(){
                        var hide=$hide;
                        document.querySelectorAll('[data-fbs10-ads]').forEach(function(e){e.style.display='';e.removeAttribute('data-fbs10-ads');});
                        if(!hide)return;
                        var keys=['ممول','Sponsored','إعلان','Promoted','Paid partnership','محتوى ممول'];
                        document.querySelectorAll('[role="article"],article').forEach(function(el){
                          var t=(el.innerText||'').trim();
                          if(keys.some(function(k){return t.indexOf(k)>=0;})){el.style.setProperty('display','none','important');el.setAttribute('data-fbs10-ads','1');}
                        });
                      })();
                  """.trimIndent()
                  webView.evaluateJavascript(js, null)
              }

              private fun injectSuggestions() {
                  val master = isSuggestionsHidden
                  val groups = hideSuggestedGroups
                  val verified = hideVerifiedPosts
                  val reels = hideReels
                  val stories = hideStories
                  val people = hidePeopleYouMayKnow
                  val pages = hidePagesYouMayLike
                  val unknown = hideUnknownSuggestedPosts
                  val js = """
                      (function(){
                        document.querySelectorAll('[data-fbs10-sug]').forEach(function(e){e.style.display='';e.removeAttribute('data-fbs10-sug');});
                        var rules=[];
                        if($master) rules.push('قد تعجبك','اقتراحات');
                        if($people) rules.push('أشخاص قد تعرفهم','People you may know');
                        if($reels) rules.push('ريلز','Reels');
                        if($stories) rules.push('قصص','Stories');
                        if($pages) rules.push('صفحات قد تعجبك','Pages you may like');
                        if($groups) rules.push('مجموعات قد تعجبك','Suggested groups','Groups you may like');
                        if($unknown) rules.push('Suggested for you','مقترح لك');
                        document.querySelectorAll('[role="article"],article').forEach(function(el){
                          var t=(el.innerText||'').trim();
                          if(!t)return;
                          var found=rules.some(function(k){return t.indexOf(k)>=0;});
                          if($groups && /(?:مجموعة|مجتمع|group)/i.test(t) && /(?:انضمام|انضم|Join|Follow)/i.test(t)) found=true;
                          if($verified){
                            var hasVerified=!!el.querySelector(
                              '[aria-label*="Verified" i],[aria-label*="موثق" i],[aria-label*="موثّق" i],' +
                              '[data-tooltip-content*="Verified" i],[title*="Verified" i],svg[aria-label*="Verified" i]'
                            );
                            if(hasVerified) found=true;
                          }
                          if(found){el.style.setProperty('display','none','important');el.setAttribute('data-fbs10-sug','1');}
                        });
                      })();
                  """.trimIndent()
                  webView.evaluateJavascript(js, null)
              }

              private fun injectTheme() {
                  val css = if (currentTheme == "dark") "body{background:#000!important;color:#fff!important;} [role=article], [role=main] div{background-color:#111!important;color:#fff!important;} a{color:#fff!important;}" else ""
                  val js = if (css.isEmpty()) {
                      "(function(){var s=document.getElementById('fbs10-theme');if(s)s.remove();})();"
                  } else {
                      """(function(){var s=document.getElementById('fbs10-theme');if(!s){s=document.createElement('style');s.id='fbs10-theme';document.head.appendChild(s);}s.textContent='$css';})();"""
                  }
                  webView.evaluateJavascript(js, null)
              }

              private fun expandComments() {
                  commentsExpandUntil = System.currentTimeMillis() + 20000L
                  clickMoreComments()
              }

              private fun clickMoreComments() {
                  if (System.currentTimeMillis() > commentsExpandUntil || isFinishing || isDestroyedCompat()) return
                  val js = """
                      (function(){
                        var keys=['عرض المزيد من التعليقات','عرض المزيد من التعليقات السابقة','عرض المزيد','View more comments','View more','See more comments'];
                        var n=0;
                        document.querySelectorAll('[role="button"],button,a').forEach(function(el){
                          var t=(el.innerText||el.textContent||'').trim();
                          if(t && keys.some(function(k){return t===k || t.indexOf(k)>=0;})){
                            try{el.click();n++;}catch(e){}
                          }
                        });
                        return n;
                      })();
                  """.trimIndent()
                  webView.evaluateJavascript(js,null)
                  badgeHandler.postDelayed({ clickMoreComments() }, 900L)
              }

              private fun fetchBadges() {
                  val jsNotif = """
                      (function() {
                          var count = 0;
                          var badge = document.querySelector('[aria-label*="إشعارات"] [role="presentation"]') || 
                                       document.querySelector('[data-visualcompletion="count"]');
                          if (badge) {
                              var txt = badge.innerText || badge.textContent || '';
                              var num = parseInt(txt.replace(/\D/g,''));
                              if (!isNaN(num)) count = num;
                          }
                          return count;
                      })();
                  """.trimIndent()
                  webView.evaluateJavascript(jsNotif) { value ->
                      try {
                          val num = value.replace("\"", "").toIntOrNull() ?: 0
                          if (num > 0) {
                              badgeNotifications.text = num.toString()
                              badgeNotifications.visibility = View.VISIBLE
                          } else {
                              badgeNotifications.visibility = View.GONE
                          }
                      } catch (e: Exception) { badgeNotifications.visibility = View.GONE }
                  }

                  val jsMsg = """
                      (function() {
                          var count = 0;
                          var badge = document.querySelector('[aria-label*="Messenger"] [role="presentation"]') ||
                                       document.querySelector('[aria-label*="الرسائل"] [role="presentation"]');
                          if (badge) {
                              var txt = badge.innerText || badge.textContent || '';
                              var num = parseInt(txt.replace(/\D/g,''));
                              if (!isNaN(num)) count = num;
                          }
                          return count;
                      })();
                  """.trimIndent()
                  webView.evaluateJavascript(jsMsg) { value ->
                      try {
                          val num = value.replace("\"", "").toIntOrNull() ?: 0
                          if (num > 0) {
                              badgeMessages.text = num.toString()
                              badgeMessages.visibility = View.VISIBLE
                          } else {
                              badgeMessages.visibility = View.GONE
                          }
                      } catch (e: Exception) { badgeMessages.visibility = View.GONE }
                  }
              }

              private fun getBestFacebookUrl(): String {
                  val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                  val caps = cm.getNetworkCapabilities(cm.activeNetwork)
                  val slow = caps?.let { it.linkDownstreamBandwidthKbps < 600 } ?: true
                  return if (slow) "https://mbasic.facebook.com/?paipv=0" else "https://m.facebook.com/?paipv=0"
              }

              override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
                  super.onActivityResult(requestCode, resultCode, data)
                  if (requestCode != FILE_CHOOSER_REQUEST) return

                  val callback = filePathCallback ?: return
                  filePathCallback = null

                  val results: Array<Uri>? = if (resultCode == RESULT_OK) {
                      val clip = data?.clipData
                      if (clip != null) {
                          Array(clip.itemCount) { i -> clip.getItemAt(i).uri }
                      } else {
                          data?.data?.let { arrayOf(it) }
                      }
                  } else null

                  callback.onReceiveValue(results)
              }

              override fun onRequestPermissionsResult(
                  requestCode: Int,
                  permissions: Array<out String>,
                  grantResults: IntArray
              ) {
                  super.onRequestPermissionsResult(requestCode, permissions, grantResults)
                  if (requestCode == FILE_CHOOSER_REQUEST &&
                      grantResults.isNotEmpty() &&
                      grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                      Toast.makeText(this, "يمكن اختيار الملفات من منتقي الملفات حتى بدون صلاحية التخزين.", Toast.LENGTH_SHORT).show()
                  }
              }

              override fun onResume() {
                  super.onResume()
                  badgeHandler.removeCallbacks(badgeRunnable)
                  badgeHandler.post(badgeRunnable)
              }

              override fun onPause() {
                  badgeHandler.removeCallbacks(badgeRunnable)
                  super.onPause()
              }

              private fun isDestroyedCompat(): Boolean = Build.VERSION.SDK_INT >= 17 && isDestroyed

              override fun onBackPressed() {
                  if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
              }

              override fun onSaveInstanceState(outState: Bundle) {
                  super.onSaveInstanceState(outState)
                  webView.saveState(outState)
              }

              override fun onRestoreInstanceState(savedInstanceState: Bundle) {
                  super.onRestoreInstanceState(savedInstanceState)
                  webView.restoreState(savedInstanceState)
              }
          }
