# FBs10 — GitHub APK Builder

هذا المشروع مجهز للبناء المجاني بواسطة GitHub Actions.

## طريقة البناء

1. ارفع محتويات هذا المشروع إلى مستودع GitHub جديد.
2. افتح تبويب **Actions**.
3. اختر **Build FBs10 APK**.
4. اضغط **Run workflow**.
5. بعد انتهاء البناء افتح نتيجة التشغيل.
6. من قسم **Artifacts** نزّل **FBs10-APK**.
7. فك ضغط ملف الـArtifact وستجد APK جاهزًا للتثبيت.

## ملاحظات

- البناء يستخدم Android Gradle Plugin 8.2.2.
- يستخدم Gradle 8.2.1 وJDK 17.
- نسخة Release الحالية موقعة بمفتاح debug الموجود في إعدادات Android Gradle، لذلك هي مناسبة للاختبار والتثبيت، وليست توقيعًا نهائيًا للنشر على Google Play.
- لا تحتاج إلى Code2Native أو Credits لهذا البناء.
