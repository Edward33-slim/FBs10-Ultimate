# طريقة البناء في GitHub

1. أنشئ/استخدم مستودع FBs10.
2. ارفع محتويات المشروع إلى جذر المستودع، وليس ملف ZIP فقط.
3. تأكد أن هذه الملفات ظاهرة في الصفحة الرئيسية:
   settings.gradle
   build.gradle
   gradle.properties
   app/build.gradle
   .github/workflows/build-apk.yml
4. افتح Actions.
5. اختر Build FBs10 Browser APK.
6. شغّل Run workflow.
7. بعد النجاح ستجد Artifact باسم FBs10-Browser-release-APK.

إذا ظهر:
"does not contain a Gradle build"
فهذا يعني عادة أن settings.gradle وbuild.gradle وapp/build.gradle ليست في جذر المستودع الذي يعمل منه GitHub Actions.
