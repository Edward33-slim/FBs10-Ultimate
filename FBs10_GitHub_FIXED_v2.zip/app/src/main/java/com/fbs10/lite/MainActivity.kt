          package com.fbs10.lite

          import android.annotation.SuppressLint
          import android.content.Context
          import android.content.SharedPreferences
          import android.graphics.Color
          import android.net.ConnectivityManager
          import android.os.Build
          import android.os.Bundle
import android.os.Handler
import android.os.Looper
          import android.view.View
import android.view.LayoutInflater
          import android.webkit.WebChromeClient
          import android.webkit.WebResourceRequest
import android.webkit.WebResourceError
          import android.webkit.WebResourceResponse
          import android.webkit.WebView
import android.webkit.WebSettings
import android.webkit.CookieManager
          import android.webkit.WebViewClient
          import android.widget.ImageView
          import android.widget.TextView
          import android.widget.Toast
          import androidx.appcompat.app.AlertDialog
          import androidx.appcompat.app.AppCompatActivity
          import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
          import com.google.android.material.bottomsheet.BottomSheetDialog
          import com.google.android.material.tabs.TabLayout
          import java.io.ByteArrayInputStream

          class MainActivity : AppCompatActivity() {

              private lateinit var webView: WebView
              private lateinit var swipeRefresh: SwipeRefreshLayout
              private lateinit var prefs: SharedPreferences

              private var isAdsHidden = true
              private var isMediaHidden = true
              private var isSuggestionsHidden = true
              private var currentTheme = "light"

              private val favorites = mutableListOf<String>()
              private val badgeHandler = Handler(Looper.getMainLooper())
              private val badgeRunnable = object : Runnable {
                  override fun run() {
                      if (!isFinishing && !isDestroyedCompat()) {
                          fetchBadges()
                          badgeHandler.postDelayed(this, 30000L)
                      }
                  }
              }

              private lateinit var btnHideAds: ImageView
              private lateinit var btnHideMedia: ImageView
              private lateinit var btnHideSuggestions: ImageView
              private lateinit var btnTheme: ImageView
              private lateinit var btnAddFavorite: ImageView
              private lateinit var btnShowFavorites: ImageView
              private lateinit var badgeNotifications: TextView
              private lateinit var badgeMessages: TextView

              @SuppressLint("SetJavaScriptEnabled")
              override fun onCreate(savedInstanceState: Bundle?) {
                  super.onCreate(savedInstanceState)
                  setContentView(R.layout.activity_main)

                  prefs = getSharedPreferences("fbs10_prefs", Context.MODE_PRIVATE)
                  loadPreferences()
                  loadFavorites()

                  webView = findViewById(R.id.webView)
                  swipeRefresh = findViewById(R.id.swipeRefresh)

                  btnHideAds = findViewById(R.id.btnHideAds)
                  btnHideMedia = findViewById(R.id.btnHideMedia)
                  btnHideSuggestions = findViewById(R.id.btnHideSuggestions)
                  btnTheme = findViewById(R.id.btnTheme)
                  btnAddFavorite = findViewById(R.id.btnAddFavorite)
                  btnShowFavorites = findViewById(R.id.btnShowFavorites)
                  badgeNotifications = findViewById(R.id.badgeNotifications)
                  badgeMessages = findViewById(R.id.badgeMessages)

                  setupWebView()
                  setupControls()
                  updateButtonStates()

                  webView.loadUrl(getBestFacebookUrl())
              }

              private fun loadPreferences() {
                  isAdsHidden = prefs.getBoolean("hide_ads", true)
                  isMediaHidden = prefs.getBoolean("hide_media", true)
                  isSuggestionsHidden = prefs.getBoolean("hide_suggestions", true)
                  currentTheme = prefs.getString("theme", "light") ?: "light"
              }

              private fun savePreferences() {
                  prefs.edit().apply {
                      putBoolean("hide_ads", isAdsHidden)
                      putBoolean("hide_media", isMediaHidden)
                      putBoolean("hide_suggestions", isSuggestionsHidden)
                      putString("theme", currentTheme)
                      apply()
                  }
              }

              private fun loadFavorites() {
                  favorites.clear()
                  val list = prefs.getString("favorites_list", "")
                  if (!list.isNullOrEmpty()) {
                      favorites.addAll(list.split("|||").filter { it.isNotEmpty() })
                  }
              }

              private fun saveFavorites() {
                  prefs.edit().putString("favorites_list", favorites.joinToString("|||")).apply()
              }

              private fun updateButtonStates() {
                  btnHideAds.setColorFilter(if (isAdsHidden) Color.GRAY else Color.WHITE)
                  btnHideMedia.setColorFilter(if (isMediaHidden) Color.GRAY else Color.WHITE)
                  btnHideSuggestions.setColorFilter(if (isSuggestionsHidden) Color.GRAY else Color.WHITE)
                  btnTheme.setColorFilter(if (currentTheme == "dark") Color.BLACK else Color.WHITE)
              }

              @SuppressLint("SetJavaScriptEnabled")
              private fun setupWebView() {
                  val cookieManager = CookieManager.getInstance()
                  cookieManager.setAcceptCookie(true)
                  if (Build.VERSION.SDK_INT >= 21) cookieManager.setAcceptThirdPartyCookies(webView, true)
                  val s = webView.settings
                  s.javaScriptEnabled = true
                  s.domStorageEnabled = true
                  s.databaseEnabled = true
                  s.cacheMode = WebSettings.LOAD_CACHE_ELSE_NETWORK
                  s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                  s.useWideViewPort = true
                  s.loadWithOverviewMode = true
                  s.userAgentString = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                  if (Build.VERSION.SDK_INT >= 24) WebView.enableSlowWholeDocumentDraw()
                  webView.setLayerType(View.LAYER_TYPE_HARDWARE, null)

                  webView.webViewClient = object : WebViewClient() {
                      override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                          val url = request.url.toString()
                          if (url.contains("doubleclick.net") || url.contains("googlesyndication")) {
                              return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream("".toByteArray()))
                          }
                          if (isMediaHidden) {
                              if (url.matches(Regex(".*\\.(jpg|jpeg|png|webp|mp4|m4v)(\\?.*)?$", RegexOption.IGNORE_CASE))) {
                                  if (url.contains("emoji") || url.contains("reaction") || url.contains("sticker")) {
                                      return super.shouldInterceptRequest(view, request)
                                  }
                                  return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream("".toByteArray()))
                              }
                          }
                          return super.shouldInterceptRequest(view, request)
                      }

                      override fun onPageFinished(view: WebView?, url: String?) {
                          super.onPageFinished(view, url)
                          swipeRefresh.isRefreshing = false
                          injectAll()
                          fetchBadges()
                          expandComments()
                      }

                      override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                          super.onReceivedError(view, request, error)
                          swipeRefresh.isRefreshing = false
                      }
                  }

                  webView.webChromeClient = WebChromeClient()
                  swipeRefresh.setOnRefreshListener { webView.reload() }
              }

              private fun setupControls() {
                  btnHideAds.setOnClickListener {
                      isAdsHidden = !isAdsHidden
                      savePreferences()
                      updateButtonStates()
                      injectAds()
                      Toast.makeText(this, if (isAdsHidden) "تم حجب الإعلانات" else "إظهار الإعلانات", Toast.LENGTH_SHORT).show()
                  }

                  btnHideMedia.setOnClickListener {
                      isMediaHidden = !isMediaHidden
                      savePreferences()
                      updateButtonStates()
                      injectMedia()
                      webView.reload()
                      Toast.makeText(this, if (isMediaHidden) "تم حجب الصور والفيديو" else "إظهار الصور والفيديو", Toast.LENGTH_SHORT).show()
                  }

                  btnHideSuggestions.setOnClickListener {
                      isSuggestionsHidden = !isSuggestionsHidden
                      savePreferences()
                      updateButtonStates()
                      injectSuggestions()
                      Toast.makeText(this, if (isSuggestionsHidden) "تم حجب الاقتراحات" else "إظهار الاقتراحات", Toast.LENGTH_SHORT).show()
                  }

                  btnTheme.setOnClickListener {
                      currentTheme = if (currentTheme == "light") "dark" else "light"
                      savePreferences()
                      updateButtonStates()
                      injectTheme()
                      Toast.makeText(this, if (currentTheme == "dark") "الوضع الليلي" else "الوضع العادي", Toast.LENGTH_SHORT).show()
                  }

                  btnAddFavorite.setOnClickListener {
                      val url = webView.url ?: return@setOnClickListener
                      if (url.contains("m.facebook.com") || url.contains("mbasic.facebook.com")) {
                          if (!favorites.contains(url)) {
                              favorites.add(url)
                              saveFavorites()
                              Toast.makeText(this, "تمت إضافة المنشور إلى المفضلة", Toast.LENGTH_SHORT).show()
                          } else {
                              Toast.makeText(this, "موجود بالفعل في المفضلة", Toast.LENGTH_SHORT).show()
                          }
                      } else {
                          Toast.makeText(this, "يرجى فتح منشور أولاً", Toast.LENGTH_SHORT).show()
                      }
                  }

                  btnShowFavorites.setOnClickListener {
                      if (favorites.isEmpty()) {
                          Toast.makeText(this, "لا توجد مفضلات", Toast.LENGTH_SHORT).show()
                          return@setOnClickListener
                      }
                      val items = favorites.toTypedArray()
                      AlertDialog.Builder(this)
                          .setTitle("المفضلات")
                          .setItems(items) { _, which ->
                              webView.loadUrl(items[which])
                          }
                          .setNegativeButton("إغلاق", null)
                          .show()
                  }

                  findViewById<View>(R.id.btnNotifications).setOnClickListener {
                      webView.loadUrl("https://m.facebook.com/notifications/")
                  }

                  findViewById<View>(R.id.btnMessenger).setOnClickListener {
                      showMessengerDialog()
                  }
              }

              @SuppressLint("SetJavaScriptEnabled")
              private fun showMessengerDialog() {
                  val dialog = BottomSheetDialog(this)
                  val view = LayoutInflater.from(this).inflate(R.layout.dialog_messenger, null)
                  dialog.setContentView(view)

                  val tabLayout = view.findViewById<TabLayout>(R.id.tabLayoutMessages)
                  val innerWebView = view.findViewById<WebView>(R.id.innerWebView)
                  val innerPrefs = getSharedPreferences("fbs10_messages", Context.MODE_PRIVATE)
                  val savedTab = innerPrefs.getInt("tab", 0)

                  val cm = CookieManager.getInstance()
                  cm.setAcceptCookie(true)
                  if (Build.VERSION.SDK_INT >= 21) cm.setAcceptThirdPartyCookies(innerWebView, true)
                  val s = innerWebView.settings
                  s.javaScriptEnabled = true
                  s.domStorageEnabled = true
                  s.databaseEnabled = true
                  s.cacheMode = WebSettings.LOAD_CACHE_ELSE_NETWORK
                  s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                  s.useWideViewPort = true
                  s.loadWithOverviewMode = true
                  s.builtInZoomControls = false
                  s.displayZoomControls = false
                  s.userAgentString = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"

                  innerWebView.webViewClient = object : WebViewClient() {
                      override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = false
                      override fun onPageFinished(view: WebView?, url: String?) {
                          super.onPageFinished(view, url)
                          selectMessageCategory(innerWebView, tabLayout.selectedTabPosition)
                          updateMessageTabBadges(innerWebView, tabLayout)
                      }
                  }
                  innerWebView.webChromeClient = WebChromeClient()

                  tabLayout.addTab(tabLayout.newTab().setText("الأساسية"))
                  tabLayout.addTab(tabLayout.newTab().setText("الطلبات"))
                  tabLayout.addTab(tabLayout.newTab().setText("غير مهم"))
                  tabLayout.getTabAt(savedTab.coerceIn(0, 2))?.select()

                  tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
                      override fun onTabSelected(tab: TabLayout.Tab?) {
                          val pos = tab?.position ?: 0
                          innerPrefs.edit().putInt("tab", pos).apply()
                          selectMessageCategory(innerWebView, pos)
                          updateMessageTabBadges(innerWebView, tabLayout)
                      }
                      override fun onTabUnselected(tab: TabLayout.Tab?) {}
                      override fun onTabReselected(tab: TabLayout.Tab?) {
                          selectMessageCategory(innerWebView, tab?.position ?: 0)
                      }
                  })

                  view.findViewById<ImageView>(R.id.btnMessengerSettings).setOnClickListener {
                      innerWebView.loadUrl("https://www.facebook.com/messages/e2ee/t/")
                  }

                  innerWebView.loadUrl("https://www.facebook.com/messages/e2ee/t/")
                  dialog.show()
              }

              private fun selectMessageCategory(web: WebView, position: Int) {
                  val label = when (position) {
                      1 -> "طلبات"
                      2 -> "غير مهم"
                      else -> "الأساسية"
                  }
                  val js = """
                      (function(){
                        var target='$label';
                        var nodes=document.querySelectorAll('[role="tab"], [role="button"], a, span, div');
                        for(var i=0;i<nodes.length;i++){
                          var t=(nodes[i].innerText||nodes[i].textContent||'').trim();
                          if(t===target){ try{nodes[i].click(); return true;}catch(e){} }
                        }
                        return false;
                      })();
                  """.trimIndent()
                  web.evaluateJavascript(js, null)
              }

              private fun updateMessageTabBadges(web: WebView, tabs: TabLayout) {
                  val js = """
                    (function(){
                      var out=[0,0,0];
                      var labels=['الأساسية','طلبات','غير مهم'];
                      var nodes=document.querySelectorAll('[role="tab"], [role="button"], a, span, div');
                      for(var i=0;i<nodes.length;i++){
                        var t=(nodes[i].innerText||nodes[i].textContent||'').trim();
                        for(var j=0;j<labels.length;j++) if(t.indexOf(labels[j])>=0){
                          var txt=(nodes[i].parentElement?nodes[i].parentElement.innerText:'')||'';
                          var m=txt.match(/\\b(\\d{1,4})\\b/); if(m) out[j]=parseInt(m[1],10);
                        }
                      }
                      return out.join('|');
                    })();
                  """.trimIndent()
                  web.evaluateJavascript(js) { value ->
                      val parts = value.replace("\"", "").split("|")
                      val labels = listOf("الأساسية", "الطلبات", "غير مهم")
                      labels.forEachIndexed { i, label ->
                          val n = parts.getOrNull(i)?.toIntOrNull() ?: 0
                          tabs.getTabAt(i)?.text = if (n > 0) "$label  $n" else label
                      }
                  }
              }

              private fun injectAll() {
                  injectMedia()
                  injectAds()
                  injectSuggestions()
                  injectTheme()
              }

              private fun injectMedia() {
                  val js = """
                      (function(){
                        var hide=$isMediaHidden;
                        document.querySelectorAll('img,video,picture,source').forEach(function(el){
                          var s=(el.currentSrc||el.src||'').toLowerCase();
                          var a=(el.getAttribute('aria-label')||'').toLowerCase();
                          var cls=(el.className||'').toString().toLowerCase();
                          var keep=/emoji|reaction|sticker|like|icon/.test(s+' '+a+' '+cls);
                          if(keep) return;
                          if(hide){ el.style.setProperty('display','none','important'); el.setAttribute('data-fbs10-media','1'); }
                          else if(el.getAttribute('data-fbs10-media')){ el.style.removeProperty('display'); el.removeAttribute('data-fbs10-media'); }
                        });
                      })();
                  """.trimIndent()
                  webView.evaluateJavascript(js, null)
              }

              private fun injectAds() {
                  if (!isAdsHidden) {
                      val jsShow = """
                          (function() {
                              document.querySelectorAll('[data-fbs10-ads]').forEach(function(el) {
                                  el.style.display = '';
                                  el.removeAttribute('data-fbs10-ads');
                              });
                          })();
                      """.trimIndent()
                      webView.evaluateJavascript(jsShow, null)
                      return
                  }
                  val js = """
                      (function() {
                          var keywords = ['ممول', 'Sponsored', 'إعلان', 'Promoted', 'رصيد إعلانات', 'عزز نتائجك', 'TikTok'];
                          var items = document.querySelectorAll('div, span, article, section');
                          for (var i = 0; i < items.length; i++) {
                              var el = items[i];
                              var text = el.innerText || '';
                              var found = false;
                              for (var k = 0; k < keywords.length; k++) {
                                  if (text.includes(keywords[k])) { found = true; break; }
                              }
                              if (found) {
                                  var parent = el.closest('[role="article"]') || el.parentElement;
                                  if (parent) {
                                      parent.style.display = 'none';
                                      parent.setAttribute('data-fbs10-ads', 'true');
                                  }
                              }
                          }
                      })();
                  """.trimIndent()
                  webView.evaluateJavascript(js, null)
              }

              private fun injectSuggestions() {
                  if (!isSuggestionsHidden) {
                      val jsShow = """
                          (function() {
                              document.querySelectorAll('[data-fbs10-sug]').forEach(function(el) {
                                  el.style.display = '';
                                  el.removeAttribute('data-fbs10-sug');
                              });
                          })();
                      """.trimIndent()
                      webView.evaluateJavascript(jsShow, null)
                      return
                  }
                  val js = """
                      (function() {
                          var targets = ['قد تعجبك', 'أشخاص قد تعرفهم', 'ريلز', 'قصص', 'صفحات قد تعجبك', 'اقتراحات'];
                          var items = document.querySelectorAll('div, section, article');
                          for (var i = 0; i < items.length; i++) {
                              var el = items[i];
                              var text = el.innerText || '';
                              var found = false;
                              for (var t = 0; t < targets.length; t++) {
                                  if (text.includes(targets[t])) { found = true; break; }
                              }
                              if (found) {
                                  var parent = el.closest('[role="article"]') || el.parentElement;
                                  if (parent) {
                                      parent.style.display = 'none';
                                      parent.setAttribute('data-fbs10-sug', 'true');
                                  }
                              }
                          }
                      })();
                  """.trimIndent()
                  webView.evaluateJavascript(js, null)
              }

              private fun injectTheme() {
                  val css = if (currentTheme == "dark") "body{background:#000!important;color:#fff!important;} [role=article], [role=main] div{background-color:#111!important;color:#fff!important;} a{color:#fff!important;}" else ""
                  val js = if (css.isEmpty()) {
                      "(function(){var s=document.getElementById('fbs10-theme');if(s)s.remove();})();"
                  } else {
                      """(function(){var s=document.getElementById('fbs10-theme');if(!s){s=document.createElement('style');s.id='fbs10-theme';document.head.appendChild(s);}s.textContent='$css';})();"""
                  }
                  webView.evaluateJavascript(js, null)
              }

              private fun expandComments() {
                  val js = """
                      (function() {
                          var loaders = document.querySelectorAll('[role="button"]');
                          for (var i = 0; i < loaders.length; i++) {
                              var el = loaders[i];
                              if (el.innerText && (el.innerText.includes('عرض المزيد') || el.innerText.includes('View more'))) {
                                  el.click();
                              }
                          }
                      })();
                  """.trimIndent()
                  webView.evaluateJavascript(js, null)
              }

              private fun fetchBadges() {
                  val jsNotif = """
                      (function() {
                          var count = 0;
                          var badge = document.querySelector('[aria-label*="إشعارات"] [role="presentation"]') || 
                                       document.querySelector('[data-visualcompletion="count"]');
                          if (badge) {
                              var txt = badge.innerText || badge.textContent || '';
                              var num = parseInt(txt.replace(/\D/g,''));
                              if (!isNaN(num)) count = num;
                          }
                          return count;
                      })();
                  """.trimIndent()
                  webView.evaluateJavascript(jsNotif) { value ->
                      try {
                          val num = value.replace("\"", "").toIntOrNull() ?: 0
                          if (num > 0) {
                              badgeNotifications.text = num.toString()
                              badgeNotifications.visibility = View.VISIBLE
                          } else {
                              badgeNotifications.visibility = View.GONE
                          }
                      } catch (e: Exception) { badgeNotifications.visibility = View.GONE }
                  }

                  val jsMsg = """
                      (function() {
                          var count = 0;
                          var badge = document.querySelector('[aria-label*="Messenger"] [role="presentation"]') ||
                                       document.querySelector('[aria-label*="الرسائل"] [role="presentation"]');
                          if (badge) {
                              var txt = badge.innerText || badge.textContent || '';
                              var num = parseInt(txt.replace(/\D/g,''));
                              if (!isNaN(num)) count = num;
                          }
                          return count;
                      })();
                  """.trimIndent()
                  webView.evaluateJavascript(jsMsg) { value ->
                      try {
                          val num = value.replace("\"", "").toIntOrNull() ?: 0
                          if (num > 0) {
                              badgeMessages.text = num.toString()
                              badgeMessages.visibility = View.VISIBLE
                          } else {
                              badgeMessages.visibility = View.GONE
                          }
                      } catch (e: Exception) { badgeMessages.visibility = View.GONE }
                  }
              }

              private fun getBestFacebookUrl(): String {
                  val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                  val caps = cm.getNetworkCapabilities(cm.activeNetwork)
                  val slow = caps?.let { it.linkDownstreamBandwidthKbps < 600 } ?: true
                  return if (slow) "https://mbasic.facebook.com/?paipv=0" else "https://m.facebook.com/?paipv=0"
              }

              override fun onResume() {
                  super.onResume()
                  badgeHandler.removeCallbacks(badgeRunnable)
                  badgeHandler.post(badgeRunnable)
              }

              override fun onPause() {
                  badgeHandler.removeCallbacks(badgeRunnable)
                  super.onPause()
              }

              private fun isDestroyedCompat(): Boolean = Build.VERSION.SDK_INT >= 17 && isDestroyed

              override fun onBackPressed() {
                  if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
              }

              override fun onSaveInstanceState(outState: Bundle) {
                  super.onSaveInstanceState(outState)
                  webView.saveState(outState)
              }

              override fun onRestoreInstanceState(savedInstanceState: Bundle) {
                  super.onRestoreInstanceState(savedInstanceState)
                  webView.restoreState(savedInstanceState)
              }
          }
